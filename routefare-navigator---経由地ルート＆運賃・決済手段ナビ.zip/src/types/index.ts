/**
 * Core type definitions for RouteFare Navigator
 */

export type TransitMode = 'transit' | 'subway' | 'train' | 'bus' | 'walking' | 'taxi' | 'driving' | 'ferry' | 'tram';

export type PaymentMethodType = 
  | 'ic_card'          // 交通系IC (Suica, Pasmo, ICOCA, Kitaca, SUGOCA, nimoca, etc.)
  | 'credit_contactless' // クレジット・タッチ決済 (EMV Contactless: Visa, Master, JCB, Amex)
  | 'ticket_machine'   // 自動券売機・紙切符 (Cash/Credit card ticket)
  | 'qr_code'          // QRコード決済 (PayPay, Mobile digital pass)
  | 'cash_onboard'     // 車内現金払い (Onboard Cash)
  | 'cash_only';       // 現金のみ (Cash Only for temples/admissions)

export interface PaymentOption {
  type: PaymentMethodType;
  name: string;
  isRecommended?: boolean;
  notes?: string;
  accepted: boolean;
  details?: string;
}

export interface LocationPaymentInfo {
  acceptedMethods: PaymentMethodType[];
  admissionFee: number;
  cashOnlyWarning?: boolean;
  icCardAccepted: boolean;
  contactlessAccepted: boolean;
  qrAccepted: boolean;
  notes: string;
  ticketVendingMachine?: string;
  goshuinOrSouvenirPayment?: string;
}

export interface TransitStep {
  id: string;
  mode: TransitMode;
  lineName: string;         // e.g. "Osaka Metro 御堂筋線 (なかもず行き)", "JR神戸線 新快速"
  lineCode?: string;        // e.g. "M", "KH", "JY"
  lineColor?: string;       // e.g. "#E5171F", "#008542"
  direction?: string;       // e.g. "なかもず方面", "姫路行き"
  fromStop: string;         // e.g. "新大阪駅 (M13)"
  toStop: string;           // e.g. "本町駅 (M18)"
  durationMinutes: number;
  stopCount?: number;
  departureTime?: string;
  arrivalTime?: string;
  fare: number;             // in base currency (JPY)
  distanceKm: number;
  paymentMethods: PaymentOption[];
  notes?: string;
}

export interface Waypoint {
  id: string;
  name: string;
  address?: string;
  lat: number;
  lng: number;
  stayMinutes: number;      // 滞在時間 (e.g. 60 min)
  category?: 'station' | 'sightseeing' | 'food' | 'hotel' | 'shopping' | 'other';
  admissionFee?: number;    // Spot admission fee if any
  notes?: string;
  paymentInfo?: LocationPaymentInfo;
}

export interface PaymentDossier {
  stationOrVehicle: string;
  spotAdmission: string;
  icCardStatus: string;
  contactlessStatus: string;
  cashRequirement: string;
  bestRecommendation: string;
}

export interface RouteLeg {
  id: string;
  fromWaypointId: string;
  toWaypointId: string;
  fromName: string;
  toName: string;
  regionName: string;       // e.g. "大阪 (Osaka)", "京都 (Kyoto)", "北海道 (Hokkaido)"
  departureTime: string;    // e.g. "09:00"
  arrivalTime: string;      // e.g. "09:25"
  transitDurationMinutes: number;
  totalDistanceKm: number;
  totalFare: number;        // in JPY
  transitMode: TransitMode;
  summaryLine: string;      // e.g. "Osaka Metro 御堂筋線 (なかもず行き)"
  steps: TransitStep[];
  primaryPaymentMethod: PaymentMethodType;
  paymentOptions: PaymentOption[];
  paymentDossier?: PaymentDossier;
  tips?: string;
  isRealTransitApi?: boolean;
}

export interface Itinerary {
  id: string;
  title: string;
  description: string;
  city: string;
  region: string;
  country: string;
  baseCurrency: string;     // Default 'JPY'
  startDateTime: string;    // e.g. "2026-11-08T09:00"
  passengers: {
    adults: number;
    children: number;
    seniors: number;
  };
  waypoints: Waypoint[];
}

export type SupportedLanguage = 'ja' | 'en' | 'zh-TW' | 'zh-CN' | 'ko' | 'es' | 'fr';

export type SupportedCurrency = 'JPY' | 'USD' | 'EUR' | 'GBP' | 'TWD' | 'KRW' | 'CNY' | 'AUD' | 'CAD' | 'SGD';
