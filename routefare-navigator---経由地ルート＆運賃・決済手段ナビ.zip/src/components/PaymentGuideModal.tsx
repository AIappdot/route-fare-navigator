import React from 'react';
import { SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import {
  X,
  CreditCard,
  Smartphone,
  Banknote,
  Ticket,
  QrCode,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Sparkles
} from 'lucide-react';

interface PaymentGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: SupportedLanguage;
}

export const PaymentGuideModal: React.FC<PaymentGuideModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  if (!isOpen) return null;
  const t = TRANSLATIONS[language];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col border border-slate-200 overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg border border-amber-500/30">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">{t.paymentGuideTitle}</h2>
              <p className="text-xs text-slate-300">
                日本の鉄道・バスにおける支払いルール＆おすすめ決済
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-700 text-sm">
          
          {/* Quick Summary Recommendation Banner */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start gap-3.5">
            <Sparkles className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
            <div>
              <h4 className="font-bold text-emerald-900 text-base">
                🏆 最もおすすめ：スマホの交通系ICカード（Apple Pay / Google Wallet）
              </h4>
              <p className="text-xs text-emerald-800 mt-1 leading-relaxed">
                iPhoneのウォレットやGoogle WalletにSuicaまたはPASMOを追加すれば、クレジットカードから瞬時にチャージ可能。
                改札機やバス乗降口にかざすだけで画面のロック解除不要で瞬時に通過できます。日本全国の主要交通機関で相互利用可能です。
              </p>
            </div>
          </div>

          {/* Payment Method Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* 1. 交通系ICカード */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 hover:bg-slate-50 transition">
              <div className="flex items-center gap-2 mb-2 font-bold text-slate-900">
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>{t.paymentLabels.ic_card}</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-medium">推奨</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Suica、PASMO、ICOCA、TOICA、manaca、Kitaca、SUGOCA、nimoca、はやかけん等。
                駅改札やバスのリーダーにかざすだけ。1枚で全国の相互利用対象路線すべて乗車できます。
              </p>
              <div className="mt-2.5 pt-2.5 border-t border-slate-200 text-[11px] text-slate-500 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>JR・私鉄・地下鉄・都営バス・市バス全般で対応</span>
              </div>
            </div>

            {/* 2. クレジット・タッチ決済 (EMV Contactless) */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 hover:bg-slate-50 transition">
              <div className="flex items-center gap-2 mb-2 font-bold text-slate-900">
                <CreditCard className="w-4 h-4 text-blue-600" />
                <span>{t.paymentLabels.credit_contactless}</span>
                <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-medium">拡大中</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Visa, Mastercard, JCB, American Express等のリップルマーク付きカードやスマホタッチ。
                東京メトロ・東急・京阪・南海・西鉄や各社路線バスで導入が急速に広がっています。
              </p>
              <div className="mt-2.5 pt-2.5 border-t border-slate-200 text-[11px] text-slate-500 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span>専用タッチ改札機または専用リーダーにかざして利用</span>
              </div>
            </div>

            {/* 3. 自動券売機・紙切符 */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 hover:bg-slate-50 transition">
              <div className="flex items-center gap-2 mb-2 font-bold text-slate-900">
                <Ticket className="w-4 h-4 text-amber-600" />
                <span>{t.paymentLabels.ticket_machine}</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                駅頭の自動券売機で目的地までの区間運賃を確認し紙切符を購入。
                日本語のほか英語表示に切替可能。現金および一部クレジットカードに対応。
              </p>
              <div className="mt-2.5 pt-2.5 border-t border-slate-200 text-[11px] text-slate-500 flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>改札機に投入し、出場時に回収されます</span>
              </div>
            </div>

            {/* 4. 車内現金払い */}
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/70 hover:bg-slate-50 transition">
              <div className="flex items-center gap-2 mb-2 font-bold text-slate-900">
                <Banknote className="w-4 h-4 text-rose-600" />
                <span>{t.paymentLabels.cash_onboard}</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                バス降車時などに直接運賃箱に小銭を投入。
                両替機は千円札と小銭のみ対応。5千円・1万円札は運転席の両替機では両替できません。
              </p>
              <div className="mt-2.5 pt-2.5 border-t border-slate-200 text-[11px] text-rose-600 font-medium flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>小銭または千円札を必ず事前準備してください</span>
              </div>
            </div>

          </div>

          {/* Bus Riding Guide: Flat vs Distance based */}
          <div className="bg-slate-100 rounded-xl p-4 border border-slate-200 space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              🚌 知っておきたいバスの乗り方（2つの主要方式）
            </h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="font-bold text-blue-700 block mb-1">【方式A】前乗り・前払い・均一運賃</span>
                <p className="text-slate-600 leading-relaxed">
                  <strong>東京23区内の都営バスなど</strong>：<br/>
                  前扉から乗り、乗車時に運賃箱またはICリーダーにタッチ（一律210円）。
                  目的地の停留所に着いたら後扉からそのまま降りられます。
                </p>
              </div>

              <div className="bg-white p-3 rounded-lg border border-slate-200">
                <span className="font-bold text-emerald-700 block mb-1">【方式B】後乗り・後払い・整理券方式</span>
                <p className="text-slate-600 leading-relaxed">
                  <strong>京都市バス・郊外路線バスなど</strong>：<br/>
                  後扉から乗車。現金の場合は入口の「整理券」を取り、ICカードの場合は入口リーダーにタッチ。
                  降りる際に前扉で整理券番号と前方画面の運賃表を確認して支払い。
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded-lg transition cursor-pointer"
          >
            閉じる (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
