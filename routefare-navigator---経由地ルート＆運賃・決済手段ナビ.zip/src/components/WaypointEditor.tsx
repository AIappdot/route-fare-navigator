import React, { useState } from 'react';
import { Waypoint, SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import {
  MapPin,
  Clock,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Calendar,
  Sparkles,
  Ticket,
  CornerDownRight
} from 'lucide-react';

interface WaypointEditorProps {
  waypoints: Waypoint[];
  startDateTime: string;
  onUpdateStartDateTime: (time: string) => void;
  onUpdateWaypoints: (waypoints: Waypoint[]) => void;
  language: SupportedLanguage;
  onFocusWaypoint?: (index: number) => void;
}

export const WaypointEditor: React.FC<WaypointEditorProps> = ({
  waypoints,
  startDateTime,
  onUpdateStartDateTime,
  onUpdateWaypoints,
  language,
  onFocusWaypoint,
}) => {
  const t = TRANSLATIONS[language];
  const [newPlaceName, setNewPlaceName] = useState('');
  const [newStayMinutes, setNewStayMinutes] = useState(60);

  // Quick preset stay duration chips
  const quickStayOptions = [15, 30, 60, 90, 120];

  const handleAddWaypoint = () => {
    if (!newPlaceName.trim()) return;

    const newId = `custom_wp_${Date.now()}`;
    const newWaypoint: Waypoint = {
      id: newId,
      name: newPlaceName.trim(),
      lat: (waypoints[waypoints.length - 1]?.lat || 35.6812) + (Math.random() - 0.5) * 0.05,
      lng: (waypoints[waypoints.length - 1]?.lng || 139.7671) + (Math.random() - 0.5) * 0.05,
      stayMinutes: newStayMinutes,
      category: 'sightseeing',
      admissionFee: 0,
    };

    // Insert before the last waypoint (destination) if possible, or append
    if (waypoints.length >= 2) {
      const updated = [
        ...waypoints.slice(0, waypoints.length - 1),
        newWaypoint,
        waypoints[waypoints.length - 1],
      ];
      onUpdateWaypoints(updated);
    } else {
      onUpdateWaypoints([...waypoints, newWaypoint]);
    }

    setNewPlaceName('');
  };

  const handleRemoveWaypoint = (index: number) => {
    if (waypoints.length <= 2) return; // Keep at least origin and destination
    const updated = waypoints.filter((_, i) => i !== index);
    onUpdateWaypoints(updated);
  };

  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    const updated = [...waypoints];
    const temp = updated[index];
    updated[index] = updated[index - 1];
    updated[index - 1] = temp;
    onUpdateWaypoints(updated);
  };

  const handleMoveDown = (index: number) => {
    if (index >= waypoints.length - 1) return;
    const updated = [...waypoints];
    const temp = updated[index];
    updated[index] = updated[index + 1];
    updated[index + 1] = temp;
    onUpdateWaypoints(updated);
  };

  const handleUpdateStayTime = (index: number, minutes: number) => {
    const updated = waypoints.map((wp, i) => (i === index ? { ...wp, stayMinutes: Math.max(0, minutes) } : wp));
    onUpdateWaypoints(updated);
  };

  const handleUpdateName = (index: number, name: string) => {
    const updated = waypoints.map((wp, i) => (i === index ? { ...wp, name } : wp));
    onUpdateWaypoints(updated);
  };

  const handleUpdateAdmission = (index: number, fee: number) => {
    const updated = waypoints.map((wp, i) => (i === index ? { ...wp, admissionFee: Math.max(0, fee) } : wp));
    onUpdateWaypoints(updated);
  };

  const getWaypointBadge = (index: number, total: number) => {
    if (index === 0) {
      return {
        label: t.origin,
        sub: 'START',
        bg: 'bg-emerald-600',
        ring: 'ring-emerald-200',
        text: 'text-emerald-700',
      };
    }
    if (index === total - 1) {
      return {
        label: t.destination,
        sub: 'GOAL',
        bg: 'bg-rose-600',
        ring: 'ring-rose-200',
        text: 'text-rose-700',
      };
    }
    const letter = String.fromCharCode(65 + index - 1); // A, B, C...
    return {
      label: `${t.waypoint} ${letter}`,
      sub: letter,
      bg: 'bg-blue-600',
      ring: 'ring-blue-200',
      text: 'text-blue-700',
    };
  };

  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-200 space-y-5">
      
      {/* Header: Title & Departure Time Picker */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100 pb-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            <span>{t.planRoute}</span>
            <span className="text-xs font-normal text-slate-500">
              ({waypoints.length} 箇所)
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            始発点、経由地、終点の滞在時間・出発時刻を自由にカスタマイズ
          </p>
        </div>

        {/* Start Date & Time input */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl">
          <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-500 font-medium">{t.startTime}</span>
            <input
              type="datetime-local"
              value={startDateTime.slice(0, 16)}
              onChange={(e) => onUpdateStartDateTime(e.target.value)}
              className="text-xs font-semibold text-slate-800 bg-transparent focus:outline-none cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Waypoint List with Sequence Lines */}
      <div className="space-y-3 relative">
        {waypoints.map((wp, idx) => {
          const badge = getWaypointBadge(idx, waypoints.length);
          const isOrigin = idx === 0;
          const isDest = idx === waypoints.length - 1;

          return (
            <div
              key={wp.id}
              className={`p-3.5 rounded-xl border transition-all duration-150 ${
                isOrigin
                  ? 'bg-emerald-50/40 border-emerald-200'
                  : isDest
                  ? 'bg-rose-50/40 border-rose-200'
                  : 'bg-slate-50/80 border-slate-200 hover:border-blue-200'
              }`}
            >
              <div className="flex items-start gap-3">
                
                {/* Badge Pin */}
                <div
                  onClick={() => onFocusWaypoint?.(idx)}
                  className={`w-8 h-8 rounded-full ${badge.bg} text-white flex flex-col items-center justify-center font-bold text-xs shadow-xs ring-4 ${badge.ring} shrink-0 cursor-pointer`}
                  title="クリックして地図上でフォーカス"
                >
                  {badge.sub}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-[11px] font-bold uppercase tracking-wider ${badge.text}`}>
                      {badge.label}
                    </span>

                    {/* Move Up/Down/Delete Actions */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleMoveUp(idx)}
                        disabled={idx === 0}
                        title={t.moveUp}
                        className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-200 disabled:opacity-20 cursor-pointer"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMoveDown(idx)}
                        disabled={idx === waypoints.length - 1}
                        title={t.moveDown}
                        className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-200 disabled:opacity-20 cursor-pointer"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      {waypoints.length > 2 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveWaypoint(idx)}
                          title={t.removeWaypoint}
                          className="p-1 rounded text-rose-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Waypoint Name input */}
                  <input
                    type="text"
                    value={wp.name}
                    onChange={(e) => handleUpdateName(idx, e.target.value)}
                    className="w-full mt-1 font-semibold text-slate-900 text-sm bg-transparent border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none transition py-0.5"
                    placeholder={t.customPlaceHolder}
                  />

                  {/* Stay Duration Selector (for all stops, especially waypoints) */}
                  <div className="mt-2.5 flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200/60 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-600 font-medium shrink-0">
                      <Clock className="w-3.5 h-3.5 text-indigo-500" />
                      <span>{t.stayDuration}:</span>
                    </div>

                    {/* Quick chips */}
                    <div className="flex items-center gap-1">
                      {quickStayOptions.map((mins) => (
                        <button
                          key={mins}
                          type="button"
                          onClick={() => handleUpdateStayTime(idx, mins)}
                          className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                            wp.stayMinutes === mins
                              ? 'bg-indigo-600 text-white shadow-2xs'
                              : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {mins}{t.minutes}
                        </button>
                      ))}
                    </div>

                    {/* Custom input */}
                    <div className="flex items-center gap-1 ml-auto">
                      <input
                        type="number"
                        min="0"
                        step="5"
                        value={wp.stayMinutes}
                        onChange={(e) => handleUpdateStayTime(idx, parseInt(e.target.value) || 0)}
                        className="w-14 px-1.5 py-0.5 text-center text-xs font-bold border border-slate-200 rounded bg-white text-slate-800 focus:border-indigo-500 focus:outline-none"
                      />
                      <span className="text-slate-500 text-[11px]">{t.minutes}</span>
                    </div>
                  </div>

                  {/* Optional Admission Fee */}
                  <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center gap-1">
                      <Ticket className="w-3.5 h-3.5 text-amber-500" />
                      <span>{t.admissionFee} (1名分):</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span>¥</span>
                      <input
                        type="number"
                        min="0"
                        step="100"
                        value={wp.admissionFee || 0}
                        onChange={(e) => handleUpdateAdmission(idx, parseInt(e.target.value) || 0)}
                        className="w-16 px-1 py-0.5 text-right text-xs font-semibold border border-slate-200 rounded bg-white text-slate-800 focus:outline-none"
                        placeholder="0"
                      />
                    </div>
                  </div>

                </div>

              </div>
            </div>
          );
        })}
      </div>

      {/* Add New Waypoint Box */}
      <div className="p-3.5 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-3">
        <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
          <Plus className="w-4 h-4 text-blue-600" />
          <span>{t.addWaypoint}</span>
        </span>

        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={newPlaceName}
            onChange={(e) => setNewPlaceName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddWaypoint()}
            placeholder="例: 上野恩賜公園、銀座シックス、伏見稲荷..."
            className="flex-1 px-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-lg text-slate-900 focus:border-blue-500 focus:outline-none"
          />

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-xs text-slate-600 bg-white border border-slate-200 rounded-lg px-2 py-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>滞在:</span>
              <input
                type="number"
                min="0"
                step="15"
                value={newStayMinutes}
                onChange={(e) => setNewStayMinutes(parseInt(e.target.value) || 0)}
                className="w-12 text-center font-bold text-slate-800 bg-transparent focus:outline-none"
              />
              <span>分</span>
            </div>

            <button
              type="button"
              onClick={handleAddWaypoint}
              disabled={!newPlaceName.trim()}
              className="px-4 py-2 text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-lg transition active:scale-95 cursor-pointer flex items-center gap-1 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>追加</span>
            </button>
          </div>
        </div>
      </div>

    </div>
  );
};
