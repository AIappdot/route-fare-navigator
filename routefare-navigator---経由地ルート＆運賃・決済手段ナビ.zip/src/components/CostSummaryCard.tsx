import React from 'react';
import { RouteLeg, SupportedCurrency, SupportedLanguage, Waypoint } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { formatCurrency, formatDualCurrency } from '../data/currencies';
import { calculatePassengerFare } from '../services/routeCalculator';
import {
  Wallet,
  Clock,
  Navigation,
  Users,
  CheckCircle,
  Sparkles,
  Ticket,
  TrendingDown
} from 'lucide-react';

interface CostSummaryCardProps {
  legs: RouteLeg[];
  waypoints: Waypoint[];
  currency: SupportedCurrency;
  language: SupportedLanguage;
  passengers: {
    adults: number;
    children: number;
    seniors: number;
  };
  onUpdatePassengers: (passengers: { adults: number; children: number; seniors: number }) => void;
  dayPassRecommendation?: {
    passName: string;
    passCost: number;
    isSavings: boolean;
    difference: number;
    description: string;
  };
}

export const CostSummaryCard: React.FC<CostSummaryCardProps> = ({
  legs,
  waypoints,
  currency,
  language,
  passengers,
  onUpdatePassengers,
  dayPassRecommendation,
}) => {
  const t = TRANSLATIONS[language];

  // Calculate base transport fares (1 adult equivalent)
  const baseTransitTotalJPY = legs.reduce((acc, leg) => acc + (leg.totalFare || 0), 0);
  
  // Passenger weighted total transit fare
  const totalPassengerTransitFareJPY = calculatePassengerFare(baseTransitTotalJPY, passengers);

  // Spot admission fees total
  const admissionTotalPerPersonJPY = waypoints.reduce((acc, wp) => acc + (wp.admissionFee || 0), 0);
  const totalAdmissionJPY = calculatePassengerFare(admissionTotalPerPersonJPY, passengers);

  // Grand Total Budget
  const grandTotalBudgetJPY = totalPassengerTransitFareJPY + totalAdmissionJPY;

  // Total transit duration in minutes
  const totalTransitMinutes = legs.reduce((acc, leg) => acc + (leg.transitDurationMinutes || 0), 0);

  // Total stay duration in minutes across all waypoints
  const totalStayMinutes = waypoints.reduce((acc, wp) => acc + (wp.stayMinutes || 0), 0);

  // Overall journey time
  const totalTripMinutes = totalTransitMinutes + totalStayMinutes;
  const tripHours = Math.floor(totalTripMinutes / 60);
  const tripRemainingMins = totalTripMinutes % 60;

  // Total distance in km
  const totalDistanceKm = legs.reduce((acc, leg) => acc + (leg.totalDistanceKm || 0), 0);

  return (
    <div className="bg-gradient-to-br from-white via-slate-50 to-blue-50/40 rounded-2xl p-5 sm:p-6 shadow-sm border border-slate-200/90 relative overflow-hidden">
      
      {/* Top Banner: Big Highlighted Cost & Total Time */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        
        {/* Left: Final Fare Highlight (最終移動費合計) */}
        <div className="md:col-span-5 bg-gradient-to-tr from-slate-900 to-indigo-950 text-white rounded-xl p-4 sm:p-5 shadow-md relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-28 h-28 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center justify-between text-xs text-blue-200 font-semibold mb-1">
            <span className="flex items-center gap-1.5 uppercase tracking-wider">
              <Wallet className="w-4 h-4 text-emerald-400" />
              {t.totalFare}
            </span>
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full text-[11px]">
              {legs.length} {t.segmentBreakdown.split(' ')[0]}
            </span>
          </div>

          {/* Primary Big Fare Amount */}
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              {formatCurrency(totalPassengerTransitFareJPY, currency)}
            </span>
            {currency !== 'JPY' && (
              <span className="text-xs sm:text-sm text-slate-300 font-medium">
                (約 ¥{totalPassengerTransitFareJPY.toLocaleString()})
              </span>
            )}
          </div>

          {/* Note on per person / passenger count */}
          <div className="mt-2 text-[11px] text-slate-300 flex items-center justify-between border-t border-white/10 pt-2">
            <span>
              {passengers.adults + passengers.children + passengers.seniors}名分合計
              {passengers.children > 0 && ` (子ども${passengers.children}名半額)`}
            </span>
            <span>
              1人あたり {formatCurrency(baseTransitTotalJPY, currency)}
            </span>
          </div>
        </div>

        {/* Center: Journey Time & Distance Breakdown */}
        <div className="md:col-span-4 space-y-2">
          <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
            <Clock className="w-4 h-4 text-indigo-600" />
            <span>{t.totalTime}</span>
            <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full ml-auto">
              約 {tripHours > 0 ? `${tripHours}${t.hours} ` : ''}{tripRemainingMins}{t.minutes}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-white p-2.5 rounded-lg border border-slate-200/80 shadow-2xs">
              <span className="text-slate-500 block text-[11px]">{t.totalTransitTime}</span>
              <span className="font-bold text-slate-800 text-sm">{totalTransitMinutes} {t.minutes}</span>
            </div>
            <div className="bg-white p-2.5 rounded-lg border border-slate-200/80 shadow-2xs">
              <span className="text-slate-500 block text-[11px]">{t.totalStayTime}</span>
              <span className="font-bold text-slate-800 text-sm">{totalStayMinutes} {t.minutes}</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-600 px-1 pt-0.5">
            <span className="flex items-center gap-1">
              <Navigation className="w-3.5 h-3.5 text-blue-500" />
              {t.totalDistance}:
            </span>
            <span className="font-bold text-slate-800">{totalDistanceKm.toFixed(1)} km</span>
          </div>
        </div>

        {/* Right: Passenger Steppers */}
        <div className="md:col-span-3 bg-white p-3 rounded-xl border border-slate-200 shadow-2xs space-y-2.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 border-b border-slate-100 pb-1.5">
            <Users className="w-3.5 h-3.5 text-blue-600" />
            <span>{t.passengers}</span>
          </div>

          {/* Adults */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 font-medium">{t.adults}</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onUpdatePassengers({ ...passengers, adults: Math.max(1, passengers.adults - 1) })}
                className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center transition cursor-pointer"
              >
                -
              </button>
              <span className="font-bold w-4 text-center">{passengers.adults}</span>
              <button
                type="button"
                onClick={() => onUpdatePassengers({ ...passengers, adults: passengers.adults + 1 })}
                className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center transition cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

          {/* Children (Half fare) */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 font-medium">{t.children}</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onUpdatePassengers({ ...passengers, children: Math.max(0, passengers.children - 1) })}
                className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center transition cursor-pointer"
              >
                -
              </button>
              <span className="font-bold w-4 text-center">{passengers.children}</span>
              <button
                type="button"
                onClick={() => onUpdatePassengers({ ...passengers, children: passengers.children + 1 })}
                className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold flex items-center justify-center transition cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Admission Fees Sub-total if any exist */}
      {totalAdmissionJPY > 0 && (
        <div className="mt-4 pt-3.5 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-slate-700">
            <Ticket className="w-4 h-4 text-amber-500" />
            <span className="font-semibold">{t.admissionTotal}:</span>
            <span className="font-bold text-slate-900">{formatDualCurrency(totalAdmissionJPY, currency)}</span>
          </div>

          <div className="flex items-center gap-2 text-slate-700">
            <span className="font-bold text-indigo-900">{t.totalWithAdmissions}:</span>
            <span className="font-extrabold text-indigo-900 text-sm bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
              {formatDualCurrency(grandTotalBudgetJPY, currency)}
            </span>
          </div>
        </div>
      )}

      {/* Day Pass Comparison Banner */}
      {dayPassRecommendation && (
        <div className="mt-4 p-3 bg-blue-50/80 border border-blue-200/90 rounded-xl flex items-start gap-2.5 text-xs">
          {dayPassRecommendation.isSavings ? (
            <TrendingDown className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <CheckCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          )}
          <div>
            <span className="font-bold text-slate-900">
              {dayPassRecommendation.isSavings ? t.passSavingsRecommended : t.passSavingsNotNeeded}
            </span>
            <span className="text-slate-600 block mt-0.5 leading-relaxed">
              {dayPassRecommendation.description}
            </span>
          </div>
        </div>
      )}

    </div>
  );
};
