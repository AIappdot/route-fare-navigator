import React, { useEffect, useRef, useState } from 'react';
import { Waypoint, SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { calculateBearing, calculateDistanceKm } from '../services/routeCalculator';
import {
  Camera,
  Compass,
  Navigation,
  X,
  Volume2,
  AlertCircle,
  RotateCw,
  Sparkles,
  MapPin,
  Eye,
  Sliders
} from 'lucide-react';

interface CameraARViewProps {
  isOpen: boolean;
  onClose: () => void;
  waypoints: Waypoint[];
  language: SupportedLanguage;
}

export const CameraARView: React.FC<CameraARViewProps> = ({
  isOpen,
  onClose,
  waypoints,
  language,
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[language];
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Target waypoint for AR guidance (default to next waypoint or first non-origin)
  const [selectedTargetIndex, setSelectedTargetIndex] = useState<number>(
    waypoints.length > 1 ? 1 : 0
  );

  // Camera stream state
  const [streamActive, setStreamActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // GPS position (default fallback to near first waypoint if simulated)
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [gpsAccuracy, setGpsAccuracy] = useState<number | null>(null);

  // Device orientation compass heading in degrees (0..360)
  const [compassHeading, setCompassHeading] = useState<number>(0);
  const [hasCompassSensor, setHasCompassSensor] = useState<boolean>(false);

  // Manual rotation slider for testing or desktop environments without gyroscope
  const [manualHeadingOffset, setManualHeadingOffset] = useState<number>(0);
  const [showManualControls, setShowManualControls] = useState<boolean>(false);

  const targetWaypoint = waypoints[selectedTargetIndex] || waypoints[0];

  // 1. Initialize Camera
  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      try {
        setCameraError(null);
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: 'environment' },
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
          audio: false,
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          setStreamActive(true);
        }
      } catch (err: unknown) {
        console.warn('Camera permission or device not available:', err);
        setCameraError('カメラへのアクセスが許可されていないか、利用できません。ARシミュレーションモードで表示します。');
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // 2. Track Real GPS Location
  useEffect(() => {
    if (!('geolocation' in navigator)) {
      // Default to slightly offset from target for demonstration
      if (targetWaypoint) {
        setUserLocation({
          lat: targetWaypoint.lat - 0.003,
          lng: targetWaypoint.lng - 0.003,
        });
      }
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        setUserLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
        setGpsAccuracy(Math.round(pos.coords.accuracy));
      },
      (err) => {
        console.warn('GPS location error:', err);
        if (targetWaypoint && !userLocation) {
          // Fallback location 350m away from target
          setUserLocation({
            lat: targetWaypoint.lat - 0.0028,
            lng: targetWaypoint.lng - 0.0025,
          });
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 3000,
        timeout: 10000,
      }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [targetWaypoint]);

  // 3. Track Compass Heading via DeviceOrientation
  useEffect(() => {
    const handleOrientation = (e: DeviceOrientationEvent) => {
      // iOS webkitCompassHeading
      if ('webkitCompassHeading' in e && typeof (e as unknown as { webkitCompassHeading: number }).webkitCompassHeading === 'number') {
        const heading = (e as unknown as { webkitCompassHeading: number }).webkitCompassHeading;
        setCompassHeading(Math.round(heading));
        setHasCompassSensor(true);
      } else if (e.alpha !== null) {
        // Android / standard 360 - alpha
        const heading = Math.round(360 - e.alpha);
        setCompassHeading(heading);
        setHasCompassSensor(true);
      }
    };

    window.addEventListener('deviceorientation', handleOrientation, true);
    return () => window.removeEventListener('deviceorientation', handleOrientation, true);
  }, []);

  // Calculate distance & bearing to target waypoint
  const currentPos = userLocation || {
    lat: (targetWaypoint?.lat || 35.6812) - 0.0028,
    lng: (targetWaypoint?.lng || 139.7671) - 0.0025,
  };

  const distanceKm = targetWaypoint
    ? calculateDistanceKm(currentPos.lat, currentPos.lng, targetWaypoint.lat, targetWaypoint.lng)
    : 0.3;

  const distanceMeters = Math.round(distanceKm * 1000);

  const targetBearing = targetWaypoint
    ? calculateBearing(currentPos.lat, currentPos.lng, targetWaypoint.lat, targetWaypoint.lng)
    : 45;

  // Effective user heading (combines device sensor heading + optional manual offset)
  const effectiveHeading = (compassHeading + manualHeadingOffset + 360) % 360;

  // Relative angle to target: 0 = straight ahead, 90 = right, 180 = behind, 270 = left
  const relativeAngle = (targetBearing - effectiveHeading + 360) % 360;

  // Determine direction text
  const getRelativeDirectionLabel = (angle: number) => {
    if (angle >= 335 || angle <= 25) return 'この方向へ直進 (Straight Ahead)';
    if (angle > 25 && angle < 70) return '斜め前方 右へ (Slight Right)';
    if (angle >= 70 && angle <= 110) return '右折方向 (Turn Right)';
    if (angle > 110 && angle < 160) return '斜め後方 右 (Sharp Right)';
    if (angle >= 160 && angle <= 200) return '後ろ方向 (U-Turn Behind)';
    if (angle > 200 && angle < 250) return '斜め後方 左 (Sharp Left)';
    if (angle >= 250 && angle <= 290) return '左折方向 (Turn Left)';
    return '斜め前方 左へ (Slight Left)';
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col overflow-hidden select-none animate-in fade-in duration-200">
      
      {/* Real Camera Video Background */}
      <video
        ref={videoRef}
        playsInline
        muted
        autoPlay
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Simulated Camera AR Backdrop if camera fails */}
      {(!streamActive || cameraError) && (
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-950 flex flex-col items-center justify-center p-6 text-center text-white">
          <div className="w-20 h-20 rounded-full bg-blue-500/20 border border-blue-400/30 flex items-center justify-center mb-4 animate-pulse">
            <Camera className="w-10 h-10 text-blue-400" />
          </div>
          <h3 className="text-lg font-bold text-white">ARカメラ・空間ウェイファインディング</h3>
          <p className="text-xs text-slate-300 max-w-sm mt-1 leading-relaxed">
            {cameraError || 'カメラを初期化中... 実機スマートフォンのカメラ映像またはシミュレーションモードで目的地の方位・距離をリアルタイム表示します。'}
          </p>
        </div>
      )}

      {/* AR HUD Overlay Layer */}
      <div className="relative z-10 flex-1 flex flex-col justify-between p-4 sm:p-6 bg-gradient-to-b from-black/70 via-transparent to-black/80 pointer-events-none">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between pointer-events-auto">
          <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/20 text-white text-xs">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></div>
            <span className="font-bold">AR ライブ ナビゲーション</span>
            <span className="text-slate-400">|</span>
            <span className="text-slate-300 font-medium">
              方位: {Math.round(effectiveHeading)}° / 目標: {targetBearing}°
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowManualControls(!showManualControls)}
              title="方位調整スライダー"
              className="p-2.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white backdrop-blur-md border border-white/20 transition active:scale-95 cursor-pointer"
            >
              <Sliders className="w-4 h-4 text-amber-400" />
            </button>
            <button
              onClick={onClose}
              className="p-2.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white backdrop-blur-md border border-white/20 transition active:scale-95 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Target Waypoint Switcher Pill */}
        <div className="self-center mt-2 pointer-events-auto max-w-md w-full">
          <div className="bg-slate-900/85 backdrop-blur-md border border-white/20 p-2 rounded-2xl flex items-center gap-2 shadow-xl">
            <MapPin className="w-5 h-5 text-rose-400 shrink-0 ml-1" />
            <div className="flex-1 min-w-0">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
                現在の誘導目的地 (Destination)
              </span>
              <select
                value={selectedTargetIndex}
                onChange={(e) => setSelectedTargetIndex(parseInt(e.target.value))}
                className="w-full bg-transparent text-sm font-bold text-white focus:outline-none cursor-pointer truncate"
              >
                {waypoints.map((wp, i) => (
                  <option key={wp.id} value={i} className="bg-slate-900 text-white">
                    {i === 0 ? '始発点: ' : i === waypoints.length - 1 ? '終点: ' : `経由地 ${String.fromCharCode(64 + i)}: `}
                    {wp.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Center: Dynamic 3D Live Arrow Overlay pointing in real-world direction */}
        <div className="flex-1 flex flex-col items-center justify-center my-6">
          
          {/* Compass Rose Ring */}
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center">
            
            {/* Outer Circular Pulse Rings */}
            <div className="absolute inset-0 rounded-full border-2 border-dashed border-cyan-400/40 animate-spin-slow"></div>
            <div className="absolute inset-4 rounded-full border border-blue-500/30"></div>
            <div className="absolute inset-8 rounded-full bg-blue-500/10 backdrop-blur-xs"></div>

            {/* Cardinal Direction Letters (N, E, S, W) rotated with compass */}
            <div
              className="absolute inset-0 transition-transform duration-200 ease-out"
              style={{ transform: `rotate(${-effectiveHeading}deg)` }}
            >
              <span className="absolute top-1 left-1/2 -translate-x-1/2 font-extrabold text-xs text-rose-400">N (北)</span>
              <span className="absolute right-2 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-300">E (東)</span>
              <span className="absolute bottom-1 left-1/2 -translate-x-1/2 font-bold text-xs text-slate-300">S (南)</span>
              <span className="absolute left-2 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-300">W (西)</span>
            </div>

            {/* Rotating 3D Wayfinding Arrow pointing toward target */}
            <div
              className="w-40 h-40 flex items-center justify-center transition-transform duration-300 ease-out drop-shadow-[0_0_25px_rgba(59,130,246,0.8)]"
              style={{
                transform: `rotate(${relativeAngle}deg)`,
              }}
            >
              <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow">
                {/* Arrow body gradient */}
                <defs>
                  <linearGradient id="arrowGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#38BDF8" />
                    <stop offset="50%" stopColor="#2563EB" />
                    <stop offset="100%" stopColor="#1E40AF" />
                  </linearGradient>
                  <linearGradient id="glowG" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#60A5FA" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#2563EB" stopOpacity="0.2" />
                  </linearGradient>
                </defs>

                {/* Arrow Polygon */}
                <polygon
                  points="50,6 84,80 50,64 16,80"
                  fill="url(#arrowGradient)"
                  stroke="#FFFFFF"
                  strokeWidth="3.5"
                  strokeLinejoin="round"
                />

                {/* Inner Highlight spine */}
                <polygon
                  points="50,14 74,74 50,62"
                  fill="url(#glowG)"
                />

                {/* Center Core Dot */}
                <circle cx="50" cy="50" r="4.5" fill="#FFFFFF" />
              </svg>
            </div>

            {/* Real-time Distance Badge Centered Under Arrow */}
            <div className="absolute -bottom-4 bg-blue-600/90 text-white font-extrabold text-xs px-3.5 py-1 rounded-full border border-blue-400/60 shadow-lg flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 text-amber-300" />
              <span>あと {distanceMeters >= 1000 ? `${distanceKm.toFixed(1)} km` : `${distanceMeters} m`}</span>
            </div>

          </div>

          {/* Direction Label */}
          <div className="mt-8 text-center bg-black/60 backdrop-blur-md px-5 py-2.5 rounded-2xl border border-white/20 shadow-lg">
            <span className="text-xs text-cyan-300 font-bold block uppercase tracking-wider">
              {getRelativeDirectionLabel(relativeAngle)}
            </span>
            <span className="text-base font-extrabold text-white block mt-0.5">
              {targetWaypoint?.name} へ向かう
            </span>
            <span className="text-[11px] text-slate-300 block mt-0.5">
              徒歩 約 {Math.max(1, Math.round(distanceMeters / 75))} 分の距離
            </span>
          </div>

        </div>

        {/* Optional Manual Compass Adjuster (for desktop testing or recalibration) */}
        {showManualControls && (
          <div className="pointer-events-auto bg-slate-900/90 backdrop-blur-md p-3 rounded-2xl border border-white/20 text-white text-xs mb-3 space-y-2">
            <div className="flex items-center justify-between font-bold">
              <span>手動コンパス旋回シミュレータ (PC・テスト用)</span>
              <button
                onClick={() => setManualHeadingOffset(0)}
                className="text-[10px] text-blue-400 underline"
              >
                リセット
              </button>
            </div>
            <input
              type="range"
              min="0"
              max="359"
              value={manualHeadingOffset}
              onChange={(e) => setManualHeadingOffset(parseInt(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>0° (北)</span>
              <span>90° (東)</span>
              <span>180° (南)</span>
              <span>270° (西)</span>
            </div>
          </div>
        )}

        {/* Bottom Navigation Guidance Bar */}
        <div className="pointer-events-auto bg-slate-950/90 backdrop-blur-md border border-white/20 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xl">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-base shrink-0 shadow-md">
              {selectedTargetIndex === 0 ? 'S' : selectedTargetIndex === waypoints.length - 1 ? 'G' : String.fromCharCode(64 + selectedTargetIndex)}
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">
                次の目的地 / 経由駅
              </span>
              <h4 className="text-sm font-bold text-white line-clamp-1">
                {targetWaypoint?.name}
              </h4>
              <p className="text-xs text-slate-300">
                {targetWaypoint?.address || '駅構内または最寄り出入口へ直進'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end border-t sm:border-t-0 pt-2 sm:pt-0 border-white/10">
            <button
              onClick={() => {
                if (selectedTargetIndex < waypoints.length - 1) {
                  setSelectedTargetIndex(selectedTargetIndex + 1);
                } else {
                  setSelectedTargetIndex(0);
                }
              }}
              className="flex-1 sm:flex-initial px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>次の地点へ切り替え</span>
              <RotateCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
