import React, { useState } from 'react';
import { RouteLeg, Waypoint, SupportedCurrency, SupportedLanguage, PaymentMethodType } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { formatCurrency, formatDualCurrency } from '../data/currencies';
import { calculatePassengerFare } from '../services/routeCalculator';
import {
  Train,
  Bus,
  Footprints,
  Clock,
  Navigation,
  CreditCard,
  Smartphone,
  Ticket,
  Banknote,
  ChevronDown,
  ChevronUp,
  MapPin,
  Sparkles,
  ArrowRight,
  Info,
  CheckCircle2,
  AlertTriangle,
  Volume2,
  Camera,
  ShieldCheck,
  Building,
  Coins
} from 'lucide-react';

interface TimelineViewProps {
  legs: RouteLeg[];
  waypoints: Waypoint[];
  currency: SupportedCurrency;
  language: SupportedLanguage;
  passengers: {
    adults: number;
    children: number;
    seniors: number;
  };
  onFocusLeg?: (index: number) => void;
  onOpenAR?: (waypointIndex: number) => void;
  onOpenVoice?: (legIndex: number) => void;
}

export const TimelineView: React.FC<TimelineViewProps> = ({
  legs,
  waypoints,
  currency,
  language,
  passengers,
  onFocusLeg,
  onOpenAR,
  onOpenVoice,
}) => {
  const t = TRANSLATIONS[language];
  const [expandedLegIds, setExpandedLegIds] = useState<Record<string, boolean>>({
    [legs[0]?.id || '']: true, // expand first leg by default
  });

  const toggleExpand = (legId: string) => {
    setExpandedLegIds((prev) => ({
      ...prev,
      [legId]: !prev[legId],
    }));
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'bus':
        return <Bus className="w-4 h-4 text-emerald-600" />;
      case 'walking':
        return <Footprints className="w-4 h-4 text-amber-600" />;
      case 'subway':
      case 'train':
      default:
        return <Train className="w-4 h-4 text-blue-600" />;
    }
  };

  const getPaymentIcon = (type: PaymentMethodType) => {
    switch (type) {
      case 'ic_card':
        return <Smartphone className="w-4 h-4 text-emerald-600" />;
      case 'credit_contactless':
        return <CreditCard className="w-4 h-4 text-blue-600" />;
      case 'ticket_machine':
        return <Ticket className="w-4 h-4 text-amber-600" />;
      case 'cash_onboard':
      case 'cash_only':
        return <Banknote className="w-4 h-4 text-rose-600" />;
      default:
        return <CreditCard className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Section Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
            {t.segmentBreakdown}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            地域ごとの実在路線・バス行先・所要時間・詳細運賃・厳密な決済手段
          </p>
        </div>
        <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full self-start sm:self-auto">
          全 {legs.length} 区間
        </span>
      </div>

      {/* Legs List */}
      <div className="space-y-4">
        {legs.map((leg, idx) => {
          const isExpanded = !!expandedLegIds[leg.id];
          const destWaypoint = waypoints.find((w) => w.id === leg.toWaypointId) || waypoints[idx + 1];
          const fromWaypoint = waypoints.find((w) => w.id === leg.fromWaypointId) || waypoints[idx];

          // Passenger fare calculation
          const passengerLegFareJPY = calculatePassengerFare(leg.totalFare, passengers);

          return (
            <div
              key={leg.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden hover:border-blue-300 transition-all duration-200"
            >
              {/* Leg Header Bar */}
              <div
                onClick={() => {
                  toggleExpand(leg.id);
                  onFocusLeg?.(idx);
                }}
                className="p-4 sm:p-5 bg-gradient-to-r from-slate-50/90 via-white to-blue-50/30 flex flex-col md:flex-row md:items-center justify-between gap-3 cursor-pointer border-b border-slate-100"
              >
                {/* Left: Leg Number & Waypoint from -> to */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex flex-col items-center justify-center font-bold text-xs shadow-xs shrink-0">
                    <span className="text-[9px] uppercase tracking-tighter opacity-80">区間</span>
                    <span>{idx + 1}</span>
                  </div>

                  <div>
                    {/* From -> To with Region Badge */}
                    <div className="flex flex-wrap items-center gap-2 text-sm sm:text-base font-bold text-slate-900">
                      <span>{leg.fromName}</span>
                      <ArrowRight className="w-4 h-4 text-blue-500 shrink-0" />
                      <span className="text-blue-900">{leg.toName}</span>
                      {leg.regionName && (
                        <span className="text-[11px] font-semibold text-indigo-800 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full">
                          📍 {leg.regionName}
                        </span>
                      )}
                    </div>

                    {/* Prominent Transit Line / Bus Destination Name */}
                    <div className="mt-1 flex flex-wrap items-center gap-2">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-100/90 text-blue-950 font-bold text-xs border border-blue-200">
                        {getModeIcon(leg.transitMode)}
                        <span>{leg.summaryLine}</span>
                      </span>

                      {/* Timetable badge */}
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        <span>{leg.departureTime} 発 → {leg.arrivalTime} 着</span>
                        <span className="text-slate-500">({leg.transitDurationMinutes}分)</span>
                      </span>

                      <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                        約 {leg.totalDistanceKm} km
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: Individual Fare Display & Expand Button */}
                <div className="flex items-center justify-between md:justify-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                  <div className="text-left md:text-right">
                    <span className="text-[10px] text-slate-500 block uppercase font-medium">
                      {t.farePerPerson}
                    </span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-lg sm:text-xl font-extrabold text-slate-900">
                        {formatCurrency(passengerLegFareJPY, currency)}
                      </span>
                      {currency !== 'JPY' && (
                        <span className="text-xs text-slate-400 font-medium">
                          (¥{passengerLegFareJPY.toLocaleString()})
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Quick Action: Voice Readout & AR Arrow */}
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenVoice?.(idx);
                      }}
                      title="区間を音声読み上げ"
                      className="p-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 transition cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenAR?.(idx + 1);
                      }}
                      title="カメラARでこの目的地へ向かう"
                      className="p-2 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 transition cursor-pointer"
                    >
                      <Camera className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      className="p-2 rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200 transition"
                      aria-label="Toggle details"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Collapsible Details: Dossier, Steps, Payment Methods */}
              {isExpanded && (
                <div className="p-4 sm:p-5 space-y-5 bg-white text-slate-700 text-xs sm:text-sm">
                  
                  {/* Detailed Location & Station Payment Dossier (場所毎・駅毎の厳密な決済情報) */}
                  <div className="bg-slate-50/90 rounded-2xl p-4 border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
                      <span className="font-bold text-slate-900 flex items-center gap-2 text-xs sm:text-sm">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>区間＆各地点の詳細決済ガイド (Payment Dossier)</span>
                      </span>
                      <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-emerald-600" />
                        <span>推奨: {leg.paymentDossier?.bestRecommendation || '交通系ICカード'}</span>
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      
                      {/* Station / Vehicle Payment Details */}
                      <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs space-y-1">
                        <span className="font-bold text-blue-900 flex items-center gap-1">
                          <Train className="w-3.5 h-3.5 text-blue-600" />
                          <span>改札・乗り物での決済ルール:</span>
                        </span>
                        <p className="text-slate-600 leading-relaxed">
                          {leg.paymentDossier?.stationOrVehicle ||
                            '改札機にて交通系ICカード（Suica/ICOCA等全国10種相互利用）または対象改札でのクレジットカードタッチ決済が利用可能です。'}
                        </p>
                      </div>

                      {/* Spot Admission / Visit Payment Details */}
                      <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs space-y-1">
                        <span className="font-bold text-indigo-900 flex items-center gap-1">
                          <Building className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{leg.toName}の入場・拝観決済:</span>
                        </span>
                        <p className="text-slate-600 leading-relaxed">
                          {destWaypoint?.paymentInfo?.notes ||
                            leg.paymentDossier?.spotAdmission ||
                            '主要施設は各種クレジットカード・電子マネー対応。神社仏閣の拝観料やお守りは現金のみの箇所があります。'}
                        </p>
                      </div>

                    </div>

                    {/* Cash Warning notice if temple / cash only exists */}
                    {(destWaypoint?.paymentInfo?.cashOnlyWarning ||
                      leg.paymentDossier?.cashRequirement?.includes('現金') ||
                      leg.paymentDossier?.cashRequirement?.includes('必須')) && (
                      <div className="bg-amber-50 border border-amber-300 rounded-xl p-2.5 flex items-start gap-2 text-xs text-amber-900 font-medium">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold">現金の準備が必要です：</span>
                          <span className="text-amber-800 ml-1">
                            {leg.paymentDossier?.cashRequirement ||
                              destWaypoint?.paymentInfo?.notes ||
                              '拝観料やお守り、小規模飲食店は現金千円札・小銭のみ対応です。'}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Accepted Payment Badges */}
                    <div className="flex flex-wrap gap-2 pt-1 border-t border-slate-200/60">
                      {leg.paymentOptions.map((opt, pIdx) => (
                        <div
                          key={pIdx}
                          className={`px-2.5 py-1 rounded-lg border text-xs flex items-center gap-1.5 ${
                            opt.isRecommended
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold shadow-2xs'
                              : 'bg-white border-slate-200 text-slate-700'
                          }`}
                        >
                          {getPaymentIcon(opt.type)}
                          <span>{opt.name}</span>
                          {opt.notes && (
                            <span className="text-[10px] text-slate-500 ml-1 opacity-90 hidden sm:inline">
                              - {opt.notes}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>

                  </div>

                  {/* Step-by-Step Breakdown (乗り換え・駅・ホーム案内) */}
                  <div className="space-y-2">
                    <span className="font-bold text-slate-900 text-xs block">
                      乗り換え・ルート詳細ステップ:
                    </span>

                    <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden">
                      {leg.steps.map((step, sIdx) => (
                        <div
                          key={step.id || sIdx}
                          className="p-3 flex items-start gap-3 bg-white hover:bg-slate-50/50 transition"
                        >
                          <div className="p-2 rounded-lg bg-slate-100 shrink-0 mt-0.5">
                            {getModeIcon(step.mode)}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex flex-wrap items-center justify-between gap-1">
                              <span className="font-bold text-slate-900 text-xs sm:text-sm">
                                {step.lineName}
                              </span>
                              <span className="text-xs text-slate-500">
                                {step.durationMinutes}分 ({step.distanceKm} km)
                              </span>
                            </div>

                            {step.direction && (
                              <p className="text-xs text-blue-700 font-medium mt-0.5">
                                行先・方面: {step.direction}
                              </p>
                            )}

                            <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                              <span className="flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                乗車: <strong>{step.fromStop}</strong>
                              </span>
                              <span>→</span>
                              <span className="flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
                                降車: <strong>{step.toStop}</strong>
                              </span>
                              {step.stopCount && (
                                <span className="text-slate-400">({step.stopCount}駅通過)</span>
                              )}
                            </div>

                            {step.notes && (
                              <p className="mt-1 text-[11px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/60 inline-block">
                                💡 {step.notes}
                              </p>
                            )}
                          </div>

                          {step.fare > 0 && (
                            <div className="text-right shrink-0">
                              <span className="font-bold text-slate-800 text-xs">
                                {formatCurrency(step.fare, currency)}
                              </span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Waypoint Stay Duration & Booking Shortcut Banner */}
                  {destWaypoint && destWaypoint.stayMinutes > 0 && (
                    <div className="bg-gradient-to-r from-indigo-50 via-purple-50 to-amber-50/50 border border-indigo-200 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span className="text-xs text-indigo-950 font-medium">
                          到着後、<strong>{destWaypoint.name}</strong>にて{' '}
                          <span className="font-bold text-indigo-700">{destWaypoint.stayMinutes}分</span> 滞在・観光
                        </span>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-2 self-end sm:self-auto">
                        <a
                          href={`https://www.google.com/search?q=${encodeURIComponent(`${destWaypoint.name} チケット 予約 観光`)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white rounded-lg transition active:scale-95 flex items-center gap-1 cursor-pointer shadow-2xs"
                        >
                          <Ticket className="w-3.5 h-3.5" />
                          <span>事前チケット予約</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => onOpenAR?.(idx + 1)}
                          className="px-2.5 py-1 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition active:scale-95 flex items-center gap-1 cursor-pointer shadow-2xs"
                        >
                          <Camera className="w-3.5 h-3.5" />
                          <span>AR案内開始</span>
                        </button>
                      </div>
                    </div>
                  )}

                </div>
              )}
            </div>
          );
        })}
      </div>

    </div>
  );
};
