/// <reference types="google.maps" />
import React, { useEffect, useState, useRef } from 'react';
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  useMap,
  useMapsLibrary
} from '@vis.gl/react-google-maps';
import { Waypoint, RouteLeg, SupportedLanguage } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { generateGoogleMapsUrl } from '../services/routeCalculator';
import {
  ExternalLink,
  Layers,
  Maximize2,
  Navigation,
  Compass,
  AlertTriangle
} from 'lucide-react';

interface MapViewerProps {
  waypoints: Waypoint[];
  legs: RouteLeg[];
  language: SupportedLanguage;
  focusedWaypointIndex?: number | null;
  focusedLegIndex?: number | null;
  apiKey: string;
}

// Inner helper component to manage map bounds and polylines
const MapController: React.FC<{
  waypoints: Waypoint[];
  focusedWaypointIndex?: number | null;
  focusedLegIndex?: number | null;
}> = ({ waypoints, focusedWaypointIndex, focusedLegIndex }) => {
  const map = useMap();
  const mapsLib = useMapsLibrary('maps');
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  // Fit bounds when waypoints change
  useEffect(() => {
    if (!map || waypoints.length === 0) return;

    if (focusedWaypointIndex !== null && focusedWaypointIndex !== undefined && waypoints[focusedWaypointIndex]) {
      const target = waypoints[focusedWaypointIndex];
      map.panTo({ lat: target.lat, lng: target.lng });
      map.setZoom(15);
      return;
    }

    const bounds = new google.maps.LatLngBounds();
    waypoints.forEach(wp => {
      bounds.extend({ lat: wp.lat, lng: wp.lng });
    });

    map.fitBounds(bounds, { top: 60, bottom: 60, left: 60, right: 60 });
  }, [map, waypoints, focusedWaypointIndex]);

  // Draw polyline connecting legs
  useEffect(() => {
    if (!map || waypoints.length < 2) return;

    if (polylineRef.current) {
      polylineRef.current.setMap(null);
    }

    const pathCoordinates = waypoints.map(wp => ({ lat: wp.lat, lng: wp.lng }));

    const polyline = new google.maps.Polyline({
      path: pathCoordinates,
      geodesic: true,
      strokeColor: '#2563EB', // vibrant blue
      strokeOpacity: 0.85,
      strokeWeight: 5,
      map: map,
    });

    polylineRef.current = polyline;

    return () => {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
      }
    };
  }, [map, waypoints]);

  return null;
};

export const MapViewer: React.FC<MapViewerProps> = ({
  waypoints,
  legs,
  language,
  focusedWaypointIndex,
  focusedLegIndex,
  apiKey,
}) => {
  const t = TRANSLATIONS[language];
  const [quotaExceeded, setQuotaExceeded] = useState(false);

  useEffect(() => {
    const handleQuota = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuota);
  }, []);

  const defaultCenter = waypoints[0]
    ? { lat: waypoints[0].lat, lng: waypoints[0].lng }
    : { lat: 35.681236, lng: 139.767125 };

  const getPinColor = (index: number, total: number) => {
    if (index === 0) return { background: '#10B981', glyph: 'S', border: '#047857' }; // Green Start
    if (index === total - 1) return { background: '#EF4444', glyph: 'G', border: '#B91C1C' }; // Red Goal
    const letter = String.fromCharCode(65 + index - 1);
    return { background: '#3B82F6', glyph: letter, border: '#1D4ED8' }; // Blue Waypoint
  };

  const googleMapsUrl = generateGoogleMapsUrl(waypoints);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full min-h-[480px]">
      
      {/* Quota Defense Banner (required by SKILL) */}
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs text-center sticky top-0 z-50 shadow-sm flex items-center justify-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Map Header Toolbar */}
      <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
          <span className="font-bold text-slate-800 flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-blue-600" />
            <span>ルートマップ (Google Maps)</span>
          </span>
          <span className="text-slate-400">|</span>
          <span className="text-slate-500 font-medium">
            {waypoints.length} 拠点接続
          </span>
        </div>

        <a
          href={googleMapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 font-semibold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-lg border border-blue-200 transition"
        >
          <span>{t.openInGoogleMaps}</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>

      {/* Map Canvas with mandatory usage attribution and mapId */}
      <div className="flex-1 w-full relative min-h-[420px]">
        {apiKey ? (
          <APIProvider apiKey={apiKey}>
            <Map
              defaultCenter={defaultCenter}
              defaultZoom={12}
              mapId="DEMO_MAP_ID"
              internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
              style={{ width: '100%', height: '100%', minHeight: '420px' }}
              gestureHandling="greedy"
              disableDefaultUI={false}
            >
              <MapController
                waypoints={waypoints}
                focusedWaypointIndex={focusedWaypointIndex}
                focusedLegIndex={focusedLegIndex}
              />

              {/* Waypoint Advanced Markers */}
              {waypoints.map((wp, idx) => {
                const pin = getPinColor(idx, waypoints.length);
                return (
                  <AdvancedMarker
                    key={wp.id}
                    position={{ lat: wp.lat, lng: wp.lng }}
                    title={`${wp.name} (${wp.stayMinutes}分滞在)`}
                  >
                    <Pin
                      background={pin.background}
                      borderColor={pin.border}
                      glyphColor="#FFFFFF"
                      glyph={pin.glyph}
                    />
                  </AdvancedMarker>
                );
              })}
            </Map>
          </APIProvider>
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center text-slate-500">
            <AlertTriangle className="w-8 h-8 text-amber-500 mb-2" />
            <p className="font-semibold text-slate-700">Google Maps APIキーが未設定です</p>
            <p className="text-xs text-slate-400 mt-1">
              .env に VITE_GOOGLE_MAPS_API_KEY を設定してください
            </p>
          </div>
        )}
      </div>

      {/* Map Legend Footer */}
      <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 font-medium">
            <span className="w-3 h-3 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-[9px]">S</span>
            <span>始発点</span>
          </span>
          <span className="flex items-center gap-1 font-medium">
            <span className="w-3 h-3 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold text-[9px]">A</span>
            <span>経由地</span>
          </span>
          <span className="flex items-center gap-1 font-medium">
            <span className="w-3 h-3 rounded-full bg-rose-500 text-white flex items-center justify-center font-bold text-[9px]">G</span>
            <span>終点</span>
          </span>
        </div>

        <span className="text-slate-400">
          ピンをクリックして地点を確認
        </span>
      </div>

    </div>
  );
};
