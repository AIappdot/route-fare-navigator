import React from 'react';
import { SupportedLanguage, SupportedCurrency } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { CURRENCY_RATES } from '../data/currencies';
import {
  Compass,
  Globe2,
  Coins,
  CreditCard,
  Printer,
  Copy,
  ExternalLink,
  Check,
  MapPin,
  Sparkles,
  Camera,
  Volume2,
  Mic
} from 'lucide-react';

interface HeaderProps {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  currency: SupportedCurrency;
  setCurrency: (cur: SupportedCurrency) => void;
  selectedPresetKey: string;
  onSelectPreset: (key: string) => void;
  onOpenPaymentGuide: () => void;
  onOpenAR: () => void;
  onOpenVoice: () => void;
  onCopyItinerary: () => void;
  onPrintItinerary: () => void;
  onOpenGoogleMaps: () => void;
  copied: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  setLanguage,
  currency,
  setCurrency,
  selectedPresetKey,
  onSelectPreset,
  onOpenPaymentGuide,
  onOpenAR,
  onOpenVoice,
  onCopyItinerary,
  onPrintItinerary,
  onOpenGoogleMaps,
  copied,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <header className="bg-slate-900 text-white shadow-lg border-b border-slate-800 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 flex items-center justify-center shadow-md shadow-blue-500/20 ring-2 ring-white/10">
              <Compass className="w-6 h-6 text-white animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white font-sans flex items-center gap-2">
                  {t.appName}
                  <span className="hidden sm:inline-block text-[11px] font-semibold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full">
                    日本全国交通・実在路線対応
                  </span>
                </h1>
              </div>
              <p className="text-xs text-slate-300 line-clamp-1">{t.appSubtitle}</p>
            </div>
          </div>

          {/* Quick Controls: Presets, Language, Currency & Actions */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-2.5">
            
            {/* Presets Dropdown (Covering Japan Nationwide: Osaka, Kyoto, Hokkaido, Fukuoka, Tokyo) */}
            <div className="relative flex items-center bg-slate-800/90 rounded-lg p-1 border border-slate-700/80">
              <Sparkles className="w-4 h-4 text-amber-400 ml-1.5 mr-1 shrink-0" />
              <select
                value={selectedPresetKey}
                onChange={(e) => onSelectPreset(e.target.value)}
                aria-label={t.presets}
                className="bg-transparent text-xs sm:text-sm font-medium text-slate-100 pr-3 py-1 focus:outline-none cursor-pointer"
              >
                <option value="osaka_kobe" className="bg-slate-800 text-white">🏯 大阪・神戸 ベイ周遊 (Osaka & Kobe)</option>
                <option value="kyoto_heritage" className="bg-slate-800 text-white">⛩️ 京都 世界遺産めぐり (Kyoto)</option>
                <option value="hokkaido_sapporo_otaru" className="bg-slate-800 text-white">🦀 北海道・札幌〜小樽 (Hokkaido)</option>
                <option value="fukuoka_dazaifu" className="bg-slate-800 text-white">🍜 福岡・博多〜太宰府 (Fukuoka)</option>
                <option value="tokyo_classic" className="bg-slate-800 text-white">🗼 東京 王道観光 (Tokyo)</option>
              </select>
            </div>

            {/* Currency Selector */}
            <div className="flex items-center bg-slate-800/90 rounded-lg p-1 border border-slate-700/80">
              <Coins className="w-4 h-4 text-emerald-400 ml-1.5 mr-1 shrink-0" />
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as SupportedCurrency)}
                aria-label={t.currency}
                className="bg-transparent text-xs sm:text-sm font-semibold text-emerald-300 pr-2 py-1 focus:outline-none cursor-pointer"
              >
                {Object.values(CURRENCY_RATES).map((cur) => (
                  <option key={cur.code} value={cur.code} className="bg-slate-800 text-white">
                    {cur.symbol} {cur.code}
                  </option>
                ))}
              </select>
            </div>

            {/* Language Selector */}
            <div className="flex items-center bg-slate-800/90 rounded-lg p-1 border border-slate-700/80">
              <Globe2 className="w-4 h-4 text-sky-400 ml-1.5 mr-1 shrink-0" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
                aria-label={t.language}
                className="bg-transparent text-xs sm:text-sm font-medium text-slate-100 pr-2 py-1 focus:outline-none cursor-pointer"
              >
                <option value="ja" className="bg-slate-800 text-white">日本語</option>
                <option value="en" className="bg-slate-800 text-white">English</option>
                <option value="zh-TW" className="bg-slate-800 text-white">繁體中文</option>
                <option value="zh-CN" className="bg-slate-800 text-white">简体中文</option>
                <option value="ko" className="bg-slate-800 text-white">한국어</option>
                <option value="es" className="bg-slate-800 text-white">Español</option>
                <option value="fr" className="bg-slate-800 text-white">Français</option>
              </select>
            </div>

            {/* Camera AR Live Wayfinding Button */}
            <button
              onClick={onOpenAR}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-lg shadow-sm shadow-purple-900/40 transition active:scale-95 cursor-pointer"
            >
              <Camera className="w-4 h-4 text-cyan-300" />
              <span>カメラAR矢印</span>
            </button>

            {/* Voice Assistant / TTS & Q&A Button */}
            <button
              onClick={onOpenVoice}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-bold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg shadow-sm shadow-blue-900/40 transition active:scale-95 cursor-pointer"
            >
              <Volume2 className="w-4 h-4 text-amber-300" />
              <span>音声案内・対話</span>
            </button>

            {/* Payment Guide Modal Button */}
            <button
              onClick={onOpenPaymentGuide}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium bg-amber-600 hover:bg-amber-500 text-white rounded-lg shadow-sm shadow-amber-900/30 transition active:scale-95 cursor-pointer"
            >
              <CreditCard className="w-4 h-4" />
              <span className="hidden sm:inline">{t.paymentGuideButton}</span>
            </button>

            {/* Copy Itinerary */}
            <button
              onClick={onCopyItinerary}
              title={t.copySummary}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs sm:text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition active:scale-95 cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
            </button>

            {/* Print / PDF */}
            <button
              onClick={onPrintItinerary}
              title={t.printItinerary}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs sm:text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition active:scale-95 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
            </button>

            {/* Open in Google Maps */}
            <button
              onClick={onOpenGoogleMaps}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded-lg shadow-sm shadow-blue-900/40 transition active:scale-95 cursor-pointer"
            >
              <MapPin className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">Google Maps</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-80" />
            </button>

          </div>
        </div>
      </div>
    </header>
  );
};
