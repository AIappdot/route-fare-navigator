import React, { useState } from 'react';
import { Itinerary, SupportedCurrency, SupportedLanguage } from '../types';
import { getTailoredTravelDeals, TravelDeal } from '../data/travelDeals';
import { formatCurrency } from '../data/currencies';
import {
  Sparkles,
  Ticket,
  Building,
  Utensils,
  Train,
  Luggage,
  ExternalLink,
  Star,
  CheckCircle2,
  Tag,
  Flame,
  ArrowUpRight
} from 'lucide-react';

interface TravelDealsPanelProps {
  itinerary: Itinerary;
  currency: SupportedCurrency;
  language: SupportedLanguage;
}

export const TravelDealsPanel: React.FC<TravelDealsPanelProps> = ({
  itinerary,
  currency,
  language,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const deals = getTailoredTravelDeals(itinerary, currency, language);

  const filteredDeals = activeCategory === 'all'
    ? deals
    : deals.filter((d) => d.category === activeCategory);

  const categories = [
    { id: 'all', label: 'すべてのお得情報', icon: Sparkles },
    { id: 'ticket', label: '🎟️ チケット・体験', icon: Ticket },
    { id: 'hotel', label: '🏨 周辺ホテル・宿泊', icon: Building },
    { id: 'dining', label: '🍽️ ご当地グルメ予約', icon: Utensils },
    { id: 'transit', label: '🚆 新幹線・交通パス', icon: Train },
    { id: 'service', label: '🧳 手荷物預かり・eSIM', icon: Luggage },
  ];

  return (
    <div className="bg-gradient-to-br from-white via-slate-50 to-amber-50/30 rounded-3xl p-5 sm:p-6 shadow-sm border border-amber-200/80 space-y-5">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-amber-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20">
              <Flame className="w-5 h-5" />
            </span>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <span>旅をより楽しむ！おすすめ予約＆お得情報スペース</span>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-full">
                入力ルート連動
              </span>
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            設定された経由地（{itinerary.waypoints.map((w) => w.name).join(' → ')}）に合わせて、入場予約やホテル、名物グルメを厳選案内
          </p>
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto bg-amber-50 border border-amber-200 text-amber-900 text-xs px-3 py-1.5 rounded-xl font-medium">
          <Tag className="w-3.5 h-3.5 text-amber-600 shrink-0" />
          <span>事前予約で待ち時間を短縮＆割引</span>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 flex items-center gap-1.5 ${
                isActive
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Deals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDeals.map((deal) => {
          return (
            <div
              key={deal.id}
              className="bg-white rounded-2xl p-4 border border-slate-200/90 hover:border-amber-400/90 shadow-2xs hover:shadow-md transition-all duration-200 flex flex-col justify-between group"
            >
              <div className="space-y-2.5">
                
                {/* Top Badge & Provider */}
                <div className="flex items-center justify-between gap-2">
                  <span className={`text-[10px] font-bold text-white px-2 py-0.5 rounded-full ${deal.badgeColor || 'bg-blue-600'}`}>
                    {deal.tag}
                  </span>
                  <span className="text-[11px] font-medium text-slate-400 truncate">
                    {deal.provider}
                  </span>
                </div>

                {/* Deal Title */}
                <h4 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-600 transition leading-snug line-clamp-2">
                  {deal.title}
                </h4>

                {/* Description */}
                <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                  {deal.description}
                </p>

                {/* Rating & Review Count */}
                {deal.rating && (
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-600">
                    <div className="flex items-center text-amber-500 font-bold gap-0.5">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{deal.rating}</span>
                    </div>
                    {deal.reviewCount && (
                      <span className="text-slate-400">({deal.reviewCount.toLocaleString()}件のクチコミ)</span>
                    )}
                  </div>
                )}

              </div>

              {/* Bottom Price & Booking Link */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">参考目安価格</span>
                  {deal.priceJPY ? (
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-sm sm:text-base font-extrabold text-slate-900">
                        {formatCurrency(deal.priceJPY, currency)}〜
                      </span>
                      {deal.originalPriceJPY && (
                        <span className="text-[11px] text-slate-400 line-through">
                          {formatCurrency(deal.originalPriceJPY, currency)}
                        </span>
                      )}
                    </div>
                  ) : (
                    <span className="text-xs font-bold text-emerald-700">無料プランあり</span>
                  )}
                </div>

                <a
                  href={deal.bookingUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white rounded-xl shadow-xs transition active:scale-95 group-hover:bg-blue-600"
                >
                  <span>予約・詳細</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Info note */}
      <div className="text-[11px] text-slate-400 text-center pt-2">
        ※ 入力された旅程・地域情報（{itinerary.region}）に合わせて提携予約サイト・公式チケットページをご案内しています。
      </div>

    </div>
  );
};
