import React, { useState, useEffect, useRef } from 'react';
import { RouteLeg, Waypoint, SupportedLanguage, SupportedCurrency } from '../types';
import { TRANSLATIONS } from '../i18n/translations';
import { formatCurrency } from '../data/currencies';
import {
  Volume2,
  Mic,
  MicOff,
  Square,
  Play,
  Pause,
  Sparkles,
  Bot,
  Send,
  HelpCircle,
  CheckCircle,
  Loader2,
  X
} from 'lucide-react';

interface VoiceAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  legs: RouteLeg[];
  waypoints: Waypoint[];
  language: SupportedLanguage;
  currency: SupportedCurrency;
  activeLegIndex?: number | null;
}

export const VoiceAssistant: React.FC<VoiceAssistantProps> = ({
  isOpen,
  onClose,
  legs,
  waypoints,
  language,
  currency,
  activeLegIndex = 0,
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[language];

  // Speech Synthesis (TTS) State
  const [isPlayingTTS, setIsPlayingTTS] = useState(false);
  const [isPausedTTS, setIsPausedTTS] = useState(false);
  const [currentlySpeakingText, setCurrentlySpeakingText] = useState('');

  // Speech Recognition (STT) State
  const [isListening, setIsListening] = useState(false);
  const [sttTranscript, setSttTranscript] = useState('');
  const recognitionRef = useRef<unknown>(null);

  // Q&A Conversation State
  const [questionInput, setQuestionInput] = useState('');
  const [isLoadingAnswer, setIsLoadingAnswer] = useState(false);
  const [qaHistory, setQaHistory] = useState<
    Array<{ sender: 'user' | 'assistant'; text: string; time: string }>
  >([]);

  // Get BCP-47 language tag for Speech Synthesis & Recognition
  const getLanguageCode = (lang: SupportedLanguage): string => {
    switch (lang) {
      case 'ja':
        return 'ja-JP';
      case 'en':
        return 'en-US';
      case 'zh-TW':
        return 'zh-TW';
      case 'zh-CN':
        return 'zh-CN';
      case 'ko':
        return 'ko-KR';
      case 'es':
        return 'es-ES';
      case 'fr':
        return 'fr-FR';
      default:
        return 'ja-JP';
    }
  };

  const bcp47Lang = getLanguageCode(language);

  // Stop TTS on unmount or close
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Speak text using SpeechSynthesis
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) {
      alert('お使いのブラウザは音声読み上げに対応していません。');
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = bcp47Lang;
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      setIsPlayingTTS(true);
      setIsPausedTTS(false);
      setCurrentlySpeakingText(text);
    };

    utterance.onend = () => {
      setIsPlayingTTS(false);
      setIsPausedTTS(false);
      setCurrentlySpeakingText('');
    };

    utterance.onerror = (e) => {
      console.warn('Speech error:', e);
      setIsPlayingTTS(false);
      setIsPausedTTS(false);
    };

    window.speechSynthesis.speak(utterance);
  };

  const handlePauseResumeTTS = () => {
    if (!('speechSynthesis' in window)) return;

    if (isPlayingTTS && !isPausedTTS) {
      window.speechSynthesis.pause();
      setIsPausedTTS(true);
    } else if (isPausedTTS) {
      window.speechSynthesis.resume();
      setIsPausedTTS(false);
    }
  };

  const handleStopTTS = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsPlayingTTS(false);
      setIsPausedTTS(false);
      setCurrentlySpeakingText('');
    }
  };

  // Generate full route speech description
  const handleReadFullRoute = () => {
    if (legs.length === 0) return;

    let narrative = `旅程のご案内です。全${legs.length}区間のコースをご案内します。`;

    legs.forEach((leg, i) => {
      narrative += `第${i + 1}区間、${leg.fromName}から${leg.toName}へ向かいます。`;
      narrative += `利用路線は、${leg.summaryLine}です。`;
      narrative += `${leg.departureTime}発、${leg.arrivalTime}着、所要時間は${leg.transitDurationMinutes}分です。`;
      narrative += `1名あたりの運賃は、${formatCurrency(leg.totalFare, currency)}です。`;
      narrative += `推奨の決済方法は、交通系ICカードまたはクレジットカードのタッチ決済です。`;

      const destWp = waypoints.find((w) => w.id === leg.toWaypointId);
      if (destWp && destWp.stayMinutes > 0) {
        narrative += `到着後、${destWp.name}にて${destWp.stayMinutes}分滞在します。`;
      }
    });

    narrative += `以上が全行程のご案内です。安全で快適な旅をお楽しみください。`;

    speakText(narrative);
  };

  // Generate single leg speech description
  const handleReadActiveLeg = (index: number) => {
    const leg = legs[index];
    if (!leg) return;

    let text = `区間${index + 1}のご案内です。${leg.fromName}から${leg.toName}への移動です。`;
    text += `乗車路線は、${leg.summaryLine}。`;
    text += `${leg.departureTime}に出発し、${leg.arrivalTime}に到着予定です。純移動時間は約${leg.transitDurationMinutes}分、距離は約${leg.totalDistanceKm}キロです。`;
    text += `運賃は1人あたり${formatCurrency(leg.totalFare, currency)}です。`;

    if (leg.paymentDossier) {
      text += `決済案内：${leg.paymentDossier.bestRecommendation}。`;
      if (leg.paymentDossier.cashRequirement && leg.paymentDossier.cashRequirement !== '不要。') {
        text += `ご注意：${leg.paymentDossier.cashRequirement}。`;
      }
    }

    speakText(text);
  };

  // Initialize Web Speech Recognition
  const toggleListening = () => {
    // Check speech recognition support
    const SpeechRecognition =
      (window as unknown as { SpeechRecognition: unknown }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition: unknown }).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('お使いのブラウザは音声入力に対応していません。テキスト入力をご利用ください。');
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        (recognitionRef.current as { stop: () => void }).stop();
      }
      setIsListening(false);
      return;
    }

    try {
      const recognition = new (SpeechRecognition as new () => {
        lang: string;
        interimResults: boolean;
        continuous: boolean;
        onresult: (e: { results: Array<Array<{ transcript: string }>> }) => void;
        onerror: (e: unknown) => void;
        onend: () => void;
        start: () => void;
        stop: () => void;
      })();

      recognition.lang = bcp47Lang;
      recognition.interimResults = true;
      recognition.continuous = false;

      recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map((r) => r[0].transcript)
          .join('');
        setSttTranscript(transcript);
        setQuestionInput(transcript);
      };

      recognition.onerror = (e) => {
        console.warn('Speech recognition error:', e);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
      recognitionRef.current = recognition;
      setIsListening(true);
    } catch (err) {
      console.warn('Recognition start failed:', err);
      setIsListening(false);
    }
  };

  // Submit Q&A to Gemini 3.8 Flash via server endpoint
  const handleAskQuestion = async (queryText?: string) => {
    const q = (queryText || questionInput).trim();
    if (!q) return;

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Add user question to history
    setQaHistory((prev) => [...prev, { sender: 'user', text: q, time: timeStr }]);
    setQuestionInput('');
    setSttTranscript('');
    setIsLoadingAnswer(true);

    try {
      const currentLeg = legs[activeLegIndex || 0] || legs[0];
      const res = await fetch('/api/voice-qa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: q,
          language: language,
          context: {
            currentLeg: currentLeg,
            waypoints: waypoints.map((w) => ({ name: w.name, address: w.address, paymentInfo: w.paymentInfo })),
            allLegsSummary: legs.map((l) => ({ from: l.fromName, to: l.toName, line: l.summaryLine, region: l.regionName })),
          },
        }),
      });

      const data = await res.json();
      const answer = data.answer || '回答を取得できませんでした。';

      setQaHistory((prev) => [
        ...prev,
        { sender: 'assistant', text: answer, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);

      // Automatically speak the AI response aloud
      speakText(answer);
    } catch (err) {
      console.error('Voice Q&A fetch failed:', err);
      const fallback = '申し訳ありません。回答の生成に失敗しました。この区間はSuicaやICOCA等の交通系ICカードまたはタッチ決済が便利です。';
      setQaHistory((prev) => [...prev, { sender: 'assistant', text: fallback, time: timeStr }]);
      speakText(fallback);
    } finally {
      setIsLoadingAnswer(false);
    }
  };

  // Preset question chips
  const quickQuestions = [
    'この区間はSuicaやクレカのタッチ決済で乗れますか？',
    'バスの乗り降りと運賃の支払いルールは？',
    '次の目的地の入場料・拝観料にキャッシュレスは使えますか？',
    '乗り換えの際、何番線ホームへ向かえば良いですか？',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-cyan-300 shadow-inner">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold flex items-center gap-2">
                <span>音声案内＆AIトラベル対話</span>
                <span className="text-[10px] bg-blue-400/20 text-cyan-300 border border-cyan-400/30 px-2 py-0.5 rounded-full font-semibold">
                  Gemini 3.8 Flash
                </span>
              </h3>
              <p className="text-xs text-slate-300">
                多言語音声読み上げ ＆ 交通・決済の疑問に音声で即答
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              handleStopTTS();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm flex-1">
          
          {/* Section 1: Route Audio Playback Controls */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50/60 border border-blue-200 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 text-xs sm:text-sm flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-blue-600" />
                <span>ルート音声読み上げ案内 (Text-to-Speech)</span>
              </span>

              {isPlayingTTS && (
                <div className="flex items-center gap-1">
                  <span className="w-1.5 h-4 bg-blue-600 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-6 bg-indigo-600 rounded-full animate-bounce [animation-delay:0.15s]"></span>
                  <span className="w-1.5 h-3 bg-cyan-600 rounded-full animate-bounce [animation-delay:0.3s]"></span>
                  <span className="text-[11px] font-bold text-blue-800 ml-1">再生中...</span>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleReadFullRoute}
                className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer active:scale-95"
              >
                <Play className="w-3.5 h-3.5" />
                <span>全行程を音声案内</span>
              </button>

              <button
                type="button"
                onClick={() => handleReadActiveLeg(activeLegIndex || 0)}
                className="px-3.5 py-2 bg-white hover:bg-slate-100 text-blue-900 border border-blue-300 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <Play className="w-3.5 h-3.5 text-blue-600" />
                <span>区間 {(activeLegIndex || 0) + 1} を読み上げ</span>
              </button>

              {isPlayingTTS && (
                <>
                  <button
                    type="button"
                    onClick={handlePauseResumeTTS}
                    className="p-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs transition cursor-pointer"
                    title={isPausedTTS ? '再開' : '一時停止'}
                  >
                    {isPausedTTS ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={handleStopTTS}
                    className="p-2 bg-rose-100 hover:bg-rose-200 text-rose-700 rounded-xl text-xs transition cursor-pointer"
                    title="停止"
                  >
                    <Square className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>

            {currentlySpeakingText && (
              <p className="text-xs text-blue-900 bg-white/80 p-2.5 rounded-xl border border-blue-200/80 leading-relaxed italic line-clamp-3">
                "{currentlySpeakingText}"
              </p>
            )}
          </div>

          {/* Section 2: Interactive Voice Q&A with Gemini */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 text-xs sm:text-sm flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>交通・決済の質問に音声で回答</span>
              </span>
              <span className="text-[11px] text-slate-500 font-medium">
                マイクまたは文字で質問
              </span>
            </div>

            {/* Quick Questions Chips */}
            <div className="flex flex-wrap gap-1.5">
              {quickQuestions.map((chip, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleAskQuestion(chip)}
                  disabled={isLoadingAnswer}
                  className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200 text-slate-700 rounded-lg border border-slate-200 transition cursor-pointer disabled:opacity-50 text-left"
                >
                  💬 {chip}
                </button>
              ))}
            </div>

            {/* Conversation Log */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 min-h-[160px] max-h-[260px] overflow-y-auto space-y-3">
              {qaHistory.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-28 text-center text-slate-400 text-xs">
                  <Bot className="w-8 h-8 text-slate-300 mb-1" />
                  <p>「このバスは整理券ですか？」「大阪城の入場料はクレカ使えますか？」など、</p>
                  <p>ルートや決済に関する質問を自由に話しかけてください。</p>
                </div>
              ) : (
                qaHistory.map((item, i) => (
                  <div
                    key={i}
                    className={`flex flex-col ${item.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                        item.sender === 'user'
                          ? 'bg-blue-600 text-white rounded-tr-none'
                          : 'bg-white text-slate-800 border border-slate-200 shadow-2xs rounded-tl-none'
                      }`}
                    >
                      {item.text}
                    </div>
                    <span className="text-[10px] text-slate-400 mt-0.5 px-1">{item.time}</span>
                  </div>
                ))
              )}

              {isLoadingAnswer && (
                <div className="flex items-center gap-2 text-xs text-indigo-700 bg-indigo-50 p-2 rounded-xl border border-indigo-200 w-fit">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Geminiがルートと決済情報を確認して回答を生成中...</span>
                </div>
              )}
            </div>

            {/* Input Bar: Microphone + Text Input + Send */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleListening}
                className={`p-3 rounded-2xl transition shadow-md active:scale-95 cursor-pointer flex items-center justify-center shrink-0 ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse ring-4 ring-rose-200'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                }`}
                title={isListening ? '音声認識を停止' : 'マイクで話しかける'}
              >
                {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              <input
                type="text"
                value={questionInput}
                onChange={(e) => setQuestionInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAskQuestion()}
                placeholder={isListening ? 'お話しください... 音声を認識中' : '質問を入力またはマイクを押して質問...'}
                className="flex-1 px-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-2xl text-slate-900 focus:border-blue-500 focus:bg-white focus:outline-none"
              />

              <button
                type="button"
                onClick={() => handleAskQuestion()}
                disabled={!questionInput.trim() || isLoadingAnswer}
                className="p-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-2xl transition shadow-md cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500">
          <span>言語: {bcp47Lang}</span>
          <button
            onClick={() => {
              handleStopTTS();
              onClose();
            }}
            className="px-4 py-1.5 font-semibold bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            閉じる
          </button>
        </div>

      </div>
    </div>
  );
};
