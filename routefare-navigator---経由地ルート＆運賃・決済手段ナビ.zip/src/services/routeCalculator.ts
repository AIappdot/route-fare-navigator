import { Waypoint, RouteLeg, TransitStep, Itinerary, PaymentDossier, PaymentOption } from '../types';

/**
 * Add minutes to a Date object and return a new Date
 */
export function addMinutesToDate(date: Date, minutes: number): Date {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

/**
 * Format Date to HH:mm
 */
export function formatTimeHHMM(date: Date): string {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * Calculate distance between two lat/lng in kilometers (Haversine formula)
 */
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return parseFloat((R * c).toFixed(1));
}

export type JapanRegion =
  | 'osaka'
  | 'kyoto'
  | 'hokkaido'
  | 'fukuoka'
  | 'nagoya'
  | 'hiroshima'
  | 'okinawa'
  | 'tokyo'
  | 'general';

/**
 * Identify the geographic region of two waypoints
 */
export function detectRegion(from: Waypoint, to: Waypoint): {
  regionCode: JapanRegion;
  regionName: string;
} {
  const avgLat = (from.lat + to.lat) / 2;
  const avgLng = (from.lng + to.lng) / 2;
  const text = `${from.name} ${from.address || ''} ${to.name} ${to.address || ''}`.toLowerCase();

  // Osaka
  if (
    text.includes('大阪') ||
    text.includes('難波') ||
    text.includes('なんば') ||
    text.includes('梅田') ||
    text.includes('心斎橋') ||
    text.includes('天王寺') ||
    text.includes('新大阪') ||
    text.includes('道頓堀') ||
    text.includes('通天閣') ||
    (avgLat >= 34.55 && avgLat <= 34.82 && avgLng >= 135.35 && avgLng <= 135.65)
  ) {
    return { regionCode: 'osaka', regionName: '大阪 (Osaka)' };
  }

  // Kyoto
  if (
    text.includes('京都') ||
    text.includes('祇園') ||
    text.includes('嵐山') ||
    text.includes('清水寺') ||
    text.includes('金閣寺') ||
    text.includes('伏見稲荷') ||
    text.includes('烏丸') ||
    text.includes('河原町') ||
    (avgLat >= 34.88 && avgLat <= 35.15 && avgLng >= 135.65 && avgLng <= 135.88)
  ) {
    return { regionCode: 'kyoto', regionName: '京都 (Kyoto)' };
  }

  // Hokkaido
  if (
    text.includes('北海道') ||
    text.includes('札幌') ||
    text.includes('小樽') ||
    text.includes('函館') ||
    text.includes('千歳') ||
    text.includes('すすきの') ||
    text.includes('大通') ||
    (avgLat >= 41.5 && avgLat <= 45.5 && avgLng >= 139.5 && avgLng <= 145.5)
  ) {
    return { regionCode: 'hokkaido', regionName: '北海道 (Hokkaido)' };
  }

  // Fukuoka / Kyushu
  if (
    text.includes('福岡') ||
    text.includes('博多') ||
    text.includes('天神') ||
    text.includes('太宰府') ||
    text.includes('中洲') ||
    (avgLat >= 33.0 && avgLat <= 34.0 && avgLng >= 129.8 && avgLng <= 131.2)
  ) {
    return { regionCode: 'fukuoka', regionName: '福岡・九州 (Fukuoka)' };
  }

  // Nagoya / Chubu
  if (
    text.includes('名古屋') ||
    text.includes('栄') ||
    text.includes('熱田') ||
    text.includes('大須') ||
    (avgLat >= 35.0 && avgLat <= 35.35 && avgLng >= 136.75 && avgLng <= 137.1)
  ) {
    return { regionCode: 'nagoya', regionName: '愛知・名古屋 (Nagoya)' };
  }

  // Hiroshima
  if (
    text.includes('広島') ||
    text.includes('宮島') ||
    text.includes('原爆ドーム') ||
    (avgLat >= 34.15 && avgLat <= 34.55 && avgLng >= 132.2 && avgLng <= 132.65)
  ) {
    return { regionCode: 'hiroshima', regionName: '広島 (Hiroshima)' };
  }

  // Okinawa
  if (
    text.includes('沖縄') ||
    text.includes('那覇') ||
    text.includes('首里') ||
    text.includes('国際通り') ||
    (avgLat >= 26.0 && avgLat <= 26.9 && avgLng >= 127.5 && avgLng <= 128.4)
  ) {
    return { regionCode: 'okinawa', regionName: '沖縄 (Okinawa)' };
  }

  // Tokyo / Kanto
  if (
    text.includes('東京') ||
    text.includes('新宿') ||
    text.includes('渋谷') ||
    text.includes('浅草') ||
    text.includes('秋葉原') ||
    text.includes('銀座') ||
    text.includes('上野') ||
    text.includes('横浜') ||
    (avgLat >= 35.4 && avgLat <= 35.9 && avgLng >= 139.4 && avgLng <= 140.0)
  ) {
    return { regionCode: 'tokyo', regionName: '東京 (Tokyo)' };
  }

  return { regionCode: 'general', regionName: '全国路線 (Japan Transit)' };
}

/**
 * Generate accurate, realistic regional transit details for two points anywhere in Japan
 */
export function estimateRegionalTransitDetails(from: Waypoint, to: Waypoint): {
  transitDurationMinutes: number;
  distanceKm: number;
  fare: number;
  summaryLine: string;
  steps: TransitStep[];
  paymentOptions: PaymentOption[];
  paymentDossier: PaymentDossier;
  regionName: string;
} {
  const dist = Math.max(0.6, calculateDistanceKm(from.lat, from.lng, to.lat, to.lng));
  const { regionCode, regionName } = detectRegion(from, to);

  let duration = Math.round(dist * 2.4 + 7);
  if (duration < 6) duration = 6;

  let fare = 190;
  let summaryLine = '';
  let lineCode = 'TR';
  let lineColor = '#2563EB';
  let primaryLineName = '';
  let paymentOptions: PaymentOption[] = [];
  let paymentDossier: PaymentDossier;

  switch (regionCode) {
    case 'osaka': {
      fare = dist < 4 ? 190 : dist < 8 ? 240 : dist < 14 ? 290 : 340;
      primaryLineName = dist < 3.5 
        ? `Osaka Metro 線 (${to.name}方面)` 
        : `Osaka Metro または JR大阪環状線 (${to.name}方面)`;
      summaryLine = `${primaryLineName} (直通・最寄り駅下車)`;
      lineCode = 'M';
      lineColor = '#E5171F';

      paymentOptions = [
        { type: 'credit_contactless', name: 'クレカ・タッチ決済 (Visa/Master/JCB/Amex)', isRecommended: true, accepted: true, notes: 'Osaka Metro全駅の改札機で直接タッチ利用可能' },
        { type: 'ic_card', name: 'ICOCA / Suica等 交通系IC (全国相互利用10種)', isRecommended: true, accepted: true, notes: '改札タッチで入退場' },
        { type: 'ticket_machine', name: '自動券売機 (紙切符)', accepted: true, notes: '現金・クレカ対応' },
      ];

      paymentDossier = {
        stationOrVehicle: `乗車駅(${from.name}最寄り)・降車駅(${to.name}最寄り)：Osaka Metro全駅およびJR西日本の改札機にてクレジットカード等のタッチ決済、ICOCA/Suica等に対応。`,
        spotAdmission: `${to.name}の入場・利用：主要観光施設はクレカ・交通系IC・PayPay対応。周辺飲食店はPayPayまたは現金対応。`,
        icCardStatus: 'ICOCA, Suica, PASMO, PiTaPa等全国10種ICカード完全利用可能。',
        contactlessStatus: 'Osaka Metroは全駅でVisa, Master, JCB, Amexタッチ改札機導入済み。切符購入不要。',
        cashRequirement: '露店での食べ歩き用に千円札・小銭があると便利ですが、交通機関は完全キャッシュレス可能。',
        bestRecommendation: 'スマホに登録したクレジットカードのタッチ決済、またはSuica/ICOCA。',
      };
      break;
    }

    case 'kyoto': {
      fare = dist < 5 ? 230 : 260;
      const isBus = dist < 7;
      primaryLineName = isBus 
        ? `京都市営バス [主要系統] (${to.name}方面行き)` 
        : `京都市営地下鉄 または 京阪電車/阪急電車 (${to.name}方面)`;
      summaryLine = isBus 
        ? `京都市営バス 均一区間 (後乗り・降車時払い)` 
        : `${primaryLineName} 最寄り駅下車`;
      lineCode = 'KYOTO';
      lineColor = '#00837B';

      paymentOptions = [
        { type: 'ic_card', name: 'ICOCA / Suica等 交通系IC', isRecommended: true, accepted: true, notes: '市バスは降車時タッチ、地下鉄は改札タッチ' },
        { type: 'credit_contactless', name: 'クレカ・タッチ決済', accepted: true, notes: '地下鉄全駅および京阪・阪急・市バス対応車両で利用可' },
        { type: 'cash_onboard', name: '車内現金払い (均一230円)', accepted: true, notes: '降車時運賃箱へ。千円札両替可。' },
      ];

      paymentDossier = {
        stationOrVehicle: `京都市営バス・地下鉄：ICOCA/Suica利用可能。地下鉄全線および京阪電車はクレジットカードタッチ決済導入済み。市バス均一区間は230円。`,
        spotAdmission: `${to.name}の拝観・入場：京都の寺社仏閣は【拝観料・お守り・御朱印が原則現金のみ】の箇所が多いため、小銭・千円札の事前準備を強く推奨。`,
        icCardStatus: 'ICOCA, Suica等全国10種IC対応。',
        contactlessStatus: '地下鉄全線・京阪電車全線でタッチ決済対応。市バスも順次拡大中。',
        cashRequirement: '【重要】寺社の拝観料納めや賽銭、一部甘味処のため現金千円札・小銭が必須です。',
        bestRecommendation: '交通は交通系ICカード、寺社拝観は現金。',
      };
      break;
    }

    case 'hokkaido': {
      fare = dist < 4 ? 210 : dist < 12 ? 260 : 640;
      primaryLineName = dist < 5 
        ? `札幌市営地下鉄 (${to.name}方面)` 
        : `JR函館本線 / 快速エアポート (${to.name}方面)`;
      summaryLine = `${primaryLineName} (最寄り駅下車)`;
      lineCode = 'SAP';
      lineColor = '#00A650';

      paymentOptions = [
        { type: 'ic_card', name: 'Kitaca / SAPICA / Suica / ICOCA', isRecommended: true, accepted: true, notes: '改札タッチで入退場' },
        { type: 'ticket_machine', name: '駅自動券売機 (紙切符)', accepted: true },
        { type: 'credit_contactless', name: 'クレカ・タッチ決済 (順次拡大中)', accepted: true },
      ];

      paymentDossier = {
        stationOrVehicle: 'JR北海道および札幌市営地下鉄：Kitaca、SAPICA、Suica等全国10種ICカード完全対応。',
        spotAdmission: `${to.name}：主要施設はクレカ・交通系IC・PayPay対応。老舗ラーメン店・海鮮市場の一部は現金のみ。`,
        icCardStatus: 'Kitaca/Suica等利用可能。',
        contactlessStatus: '地下鉄・JRともに実証実験順次拡大中。ICカードが確実。',
        cashRequirement: '市場や個人飲食店用に千円札を用意すると安心。',
        bestRecommendation: '交通系ICカード（Kitaca / Suica / Apple Pay）。',
      };
      break;
    }

    case 'fukuoka': {
      fare = dist < 3 ? 210 : dist < 8 ? 260 : 420;
      primaryLineName = dist < 6 
        ? `福岡市地下鉄 空港線/七隈線 (${to.name}方面)` 
        : `西鉄電車 または JR鹿児島本線 (${to.name}方面)`;
      summaryLine = `${primaryLineName} (全線タッチ決済対応)`;
      lineCode = 'FUK';
      lineColor = '#2470B8';

      paymentOptions = [
        { type: 'credit_contactless', name: 'クレカ・タッチ決済 (Visa/Master/JCB/Amex)', isRecommended: true, accepted: true, notes: '福岡市地下鉄・西鉄電車全駅で改札直接タッチ対応（1日上限640円）' },
        { type: 'ic_card', name: 'はやかけん / nimoca / SUGOCA / Suica', accepted: true },
        { type: 'ticket_machine', name: '自動券売機', accepted: true },
      ];

      paymentDossier = {
        stationOrVehicle: '福岡市地下鉄および西鉄電車：日本初・全駅でVisa/Master/JCB/Amexタッチ決済導入済み。1日上限640円の自動割引あり。',
        spotAdmission: `${to.name}：主要観光スポットや商業施設はキャッシュレス完全対応。中洲屋台はPayPayまたは現金。`,
        icCardStatus: 'はやかけん, nimoca, SUGOCA, Suica等全国10種IC対応。',
        contactlessStatus: '全駅改札がクレジットカードタッチ決済に完全対応。',
        cashRequirement: '中洲・天神の屋台街を利用する場合は現金千円札をご用意ください。',
        bestRecommendation: 'クレジットカードのタッチ決済（自動で1日上限適用されるため最安＆最速）。',
      };
      break;
    }

    case 'nagoya': {
      fare = dist < 4 ? 210 : dist < 8 ? 240 : 310;
      primaryLineName = `名古屋市営地下鉄 東山線/名城線 (${to.name}方面)`;
      summaryLine = `${primaryLineName} (直通・最寄り駅下車)`;
      lineCode = 'NGO';
      lineColor = '#FFB800';

      paymentOptions = [
        { type: 'ic_card', name: 'manaca / TOICA / Suica / ICOCA', isRecommended: true, accepted: true },
        { type: 'credit_contactless', name: 'クレカ・タッチ決済 (対応駅拡大中)', accepted: true },
        { type: 'ticket_machine', name: '自動券売機切符', accepted: true },
      ];

      paymentDossier = {
        stationOrVehicle: '名古屋市営地下鉄および名鉄：manaca、TOICA、Suica等全国10種IC対応。タッチ決済順次導入中。',
        spotAdmission: `${to.name}：名古屋城等はクレカ・電子マネー対応。大須商店街の食べ歩きはPayPay/現金混在。`,
        icCardStatus: 'manaca/Suica等対応。',
        contactlessStatus: '主要駅改札でタッチ決済導入中。',
        cashRequirement: '食べ歩き用に小銭があると便利。',
        bestRecommendation: '交通系ICカード（manaca / Suica）。',
      };
      break;
    }

    case 'hiroshima': {
      fare = dist < 6 ? 220 : 350;
      primaryLineName = dist < 8 
        ? `広島電鉄 (広電市内線/宮島線 路面電車)` 
        : `JR山陽本線 快速/普通 (${to.name}方面)`;
      summaryLine = `${primaryLineName} 最寄り電停/駅下車`;
      lineCode = 'HIRO';
      lineColor = '#E60012';

      paymentOptions = [
        { type: 'credit_contactless', name: 'クレカ・タッチ決済 (全線導入済み)', isRecommended: true, accepted: true, notes: '広電全車載リーダーでVisa/Master/JCBタッチ対応' },
        { type: 'ic_card', name: 'ICOCA / Suica等 交通系IC (全国相互利用)', isRecommended: true, accepted: true },
        { type: 'ticket_machine', name: '券売機・車内精算', accepted: true },
      ];

      paymentDossier = {
        stationOrVehicle: '広島電鉄路面電車・宮島フェリー：全車両でクレジットカードタッチ決済およびICOCA/Suica等対応。',
        spotAdmission: `${to.name}：厳島神社の昇殿初穂料(300円)は【現金のみ】。原爆ドーム周辺の記念資料館はクレカ・IC・コード決済可。`,
        icCardStatus: 'ICOCA/Suica等対応。新システムMOBIRY DAYSも導入。',
        contactlessStatus: '広電全線でタッチ決済対応。',
        cashRequirement: '厳島神社や宮島島内の社寺は現金必須。',
        bestRecommendation: '交通はクレカタッチ決済またはICOCA、宮島では現金小銭を併用。',
      };
      break;
    }

    case 'okinawa': {
      fare = dist < 4 ? 230 : dist < 8 ? 300 : 370;
      primaryLineName = `ゆいレール (沖縄都市モノレール) (${to.name}方面)`;
      summaryLine = `${primaryLineName} または 那覇バス`;
      lineCode = 'YUI';
      lineColor = '#C10016';

      paymentOptions = [
        { type: 'credit_contactless', name: 'クレカ・タッチ決済 (Visa/Master/JCB等)', isRecommended: true, accepted: true, notes: 'ゆいレール全駅改札で直接タッチ乗車可能' },
        { type: 'ic_card', name: 'OKICA / Suica / ICOCA等 (全国相互利用対応)', accepted: true },
        { type: 'qr_code', name: 'ゆいレールQR乗車券', accepted: true },
      ];

      paymentDossier = {
        stationOrVehicle: 'ゆいレール全駅改札：クレジットカードのタッチ決済改札およびSuica/OKICA改札完備。那覇バスはIC/現金。',
        spotAdmission: `${to.name}：首里城公園券売機はクレカ・交通系IC・電子マネー対応。国際通り店舗はキャッシュレス完備。公設市場は現金またはPayPay。`,
        icCardStatus: 'OKICAおよびSuica等全国10種IC対応。',
        contactlessStatus: 'ゆいレール全駅でタッチ決済完全対応。',
        cashRequirement: '公設市場や個人商店用に現金千円札を用意すると安心。',
        bestRecommendation: 'クレジットカードのタッチ決済。',
      };
      break;
    }

    case 'tokyo':
    default: {
      fare = dist < 3.5 ? 180 : dist < 7 ? 210 : dist < 12 ? 260 : 330;
      primaryLineName = dist < 3.5 
        ? `都営バス または 地下鉄各線 (${to.name}方面)` 
        : `主要鉄道線・快速 (${to.name}方面)`;
      summaryLine = `${primaryLineName} (最寄り駅下車)`;
      lineCode = 'TYO';
      lineColor = '#2563EB';

      paymentOptions = [
        { type: 'ic_card', name: '交通系ICカード (Suica/PASMO等)', isRecommended: true, accepted: true, notes: '改札タッチで入退場' },
        { type: 'credit_contactless', name: 'クレカ・タッチ決済', accepted: true, notes: '地下鉄・私鉄各線で順次拡大中' },
        { type: 'ticket_machine', name: '自動券売機 (紙切符)', accepted: true },
      ];

      paymentDossier = {
        stationOrVehicle: 'JR東日本・東京メトロ・都営地下鉄：Suica/PASMO対応改札完備。',
        spotAdmission: `${to.name}：展望台・美術館等はキャッシュレス対応。浅草寺などの寺社はお守り・おみくじ現金のみ。`,
        icCardStatus: 'Suica/PASMO等対応。',
        contactlessStatus: '東京メトロ・東急等でタッチ改札導入。',
        cashRequirement: '寺社のおみくじ・小規模屋台用に小銭があると安心。',
        bestRecommendation: '交通系ICカード（Suica / PASMO / Apple Pay）。',
      };
      break;
    }
  }

  const steps: TransitStep[] = [
    {
      id: `step_${from.id}_to_${to.id}_1`,
      mode: 'walking',
      lineName: '徒歩 (最寄り駅・バス停へ)',
      fromStop: from.name,
      toStop: `${from.name} 最寄り改札・停留所`,
      durationMinutes: 3,
      fare: 0,
      distanceKm: 0.2,
      paymentMethods: [{ type: 'ic_card', name: '不要', accepted: true }],
    },
    {
      id: `step_${from.id}_to_${to.id}_2`,
      mode: dist < 3.5 && regionCode === 'kyoto' ? 'bus' : 'subway',
      lineName: primaryLineName,
      lineCode: lineCode,
      lineColor: lineColor,
      direction: `${to.name}方面行き`,
      fromStop: `${from.name} 最寄り駅/停留所`,
      toStop: `${to.name} 最寄り駅/停留所`,
      durationMinutes: duration - 5,
      fare: fare,
      distanceKm: dist,
      paymentMethods: paymentOptions,
    },
    {
      id: `step_${from.id}_to_${to.id}_3`,
      mode: 'walking',
      lineName: `徒歩 (${to.name}へ到着)`,
      fromStop: `${to.name} 最寄り出口`,
      toStop: to.name,
      durationMinutes: 2,
      fare: 0,
      distanceKm: 0.1,
      paymentMethods: [{ type: 'ic_card', name: '不要', accepted: true }],
    },
  ];

  return {
    transitDurationMinutes: duration,
    distanceKm: dist,
    fare: fare,
    summaryLine: summaryLine,
    steps: steps,
    paymentOptions: paymentOptions,
    paymentDossier: paymentDossier,
    regionName: regionName,
  };
}

/**
 * Recalculate schedule (departure times, arrival times) across all legs based on itinerary start time and waypoint stay durations
 */
export function recalculateItinerarySchedule(
  itinerary: Itinerary,
  existingLegs: RouteLeg[]
): RouteLeg[] {
  const { waypoints, startDateTime } = itinerary;
  if (waypoints.length < 2) return [];

  let currentTime = new Date(startDateTime);
  const updatedLegs: RouteLeg[] = [];

  for (let i = 0; i < waypoints.length - 1; i++) {
    const fromWp = waypoints[i];
    const toWp = waypoints[i + 1];

    // If starting point has stayMinutes, add them to initial departure
    if (i === 0 && fromWp.stayMinutes > 0) {
      currentTime = addMinutesToDate(currentTime, fromWp.stayMinutes);
    }

    const departureTimeString = formatTimeHHMM(currentTime);

    // Find existing leg or estimate a new one
    const matchedLeg = existingLegs.find(
      (l) => l.fromWaypointId === fromWp.id && l.toWaypointId === toWp.id
    );

    let legDuration = 15;
    let distanceKm = 3.0;
    let fare = 210;
    let summaryLine = `直通連絡線 (${toWp.name}方面)`;
    let steps: TransitStep[] = [];
    let paymentOptions: PaymentOption[] = [];
    let paymentDossier: PaymentDossier | undefined = undefined;
    let regionName = '日本全国 (Japan)';
    let primaryPaymentMethod = matchedLeg?.primaryPaymentMethod || 'ic_card';
    let transitMode = matchedLeg?.transitMode || 'subway';
    let tips = matchedLeg?.tips;

    if (matchedLeg) {
      legDuration = matchedLeg.transitDurationMinutes;
      distanceKm = matchedLeg.totalDistanceKm;
      fare = matchedLeg.totalFare;
      summaryLine = matchedLeg.summaryLine;
      steps = matchedLeg.steps;
      paymentOptions = matchedLeg.paymentOptions;
      paymentDossier = matchedLeg.paymentDossier;
      regionName = matchedLeg.regionName;
    } else {
      const estimated = estimateRegionalTransitDetails(fromWp, toWp);
      legDuration = estimated.transitDurationMinutes;
      distanceKm = estimated.distanceKm;
      fare = estimated.fare;
      summaryLine = estimated.summaryLine;
      steps = estimated.steps;
      paymentOptions = estimated.paymentOptions;
      paymentDossier = estimated.paymentDossier;
      regionName = estimated.regionName;
      primaryPaymentMethod = estimated.paymentOptions[0]?.type || 'ic_card';
    }

    // Arrival time for this leg
    const arrivalDate = addMinutesToDate(currentTime, legDuration);
    const arrivalTimeString = formatTimeHHMM(arrivalDate);

    updatedLegs.push({
      id: matchedLeg?.id || `leg_${fromWp.id}_${toWp.id}`,
      fromWaypointId: fromWp.id,
      toWaypointId: toWp.id,
      fromName: fromWp.name,
      toName: toWp.name,
      regionName: regionName,
      departureTime: departureTimeString,
      arrivalTime: arrivalTimeString,
      transitDurationMinutes: legDuration,
      totalDistanceKm: distanceKm,
      totalFare: fare,
      transitMode: transitMode,
      summaryLine: summaryLine,
      steps: steps,
      primaryPaymentMethod: primaryPaymentMethod,
      paymentOptions: paymentOptions,
      paymentDossier: paymentDossier,
      tips: tips,
      isRealTransitApi: matchedLeg?.isRealTransitApi || false,
    });

    // Advance currentTime by leg duration + stay duration at arrival waypoint
    currentTime = addMinutesToDate(arrivalDate, toWp.stayMinutes);
  }

  return updatedLegs;
}

/**
 * Calculate passenger-weighted total fares
 */
export function calculatePassengerFare(
  baseFareJPY: number,
  passengers: { adults: number; children: number; seniors: number }
): number {
  const adultTotal = baseFareJPY * (passengers.adults || 1);
  const childTotal = Math.floor(baseFareJPY * 0.5) * (passengers.children || 0);
  const seniorTotal = baseFareJPY * (passengers.seniors || 0);
  return adultTotal + childTotal + seniorTotal;
}

/**
 * Generate Google Maps transit directions URL with origin, destination, and waypoints
 */
export function generateGoogleMapsUrl(waypoints: Waypoint[]): string {
  if (waypoints.length === 0) return 'https://www.google.com/maps';
  if (waypoints.length === 1) {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(waypoints[0].name)}`;
  }

  const origin = encodeURIComponent(waypoints[0].name);
  const destination = encodeURIComponent(waypoints[waypoints.length - 1].name);

  const midWaypoints = waypoints.slice(1, -1);
  let waypointsParam = '';
  if (midWaypoints.length > 0) {
    const encoded = midWaypoints.map((w) => encodeURIComponent(w.name)).join('|');
    waypointsParam = `&waypoints=${encoded}`;
  }

  return `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}${waypointsParam}&travelmode=transit`;
}

/**
 * Calculate target compass bearing from point 1 (lat1, lon1) to point 2 (lat2, lon2)
 * Returns angle in degrees 0..360 (0 = North, 90 = East, 180 = South, 270 = West)
 */
export function calculateBearing(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  const θ = Math.atan2(y, x);

  const bearing = ((θ * 180) / Math.PI + 360) % 360;
  return Math.round(bearing);
}
