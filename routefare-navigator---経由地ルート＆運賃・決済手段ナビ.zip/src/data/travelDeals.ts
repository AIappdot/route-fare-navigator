import { Itinerary, SupportedCurrency, SupportedLanguage } from '../types';
import { detectRegion } from '../services/routeCalculator';

export interface TravelDeal {
  id: string;
  category: 'ticket' | 'hotel' | 'dining' | 'transit' | 'service';
  title: string;
  description: string;
  provider: string;
  priceJPY?: number;
  originalPriceJPY?: number;
  tag: string;
  badgeColor?: string;
  rating?: number;
  reviewCount?: number;
  bookingUrl: string;
  targetWaypointName?: string;
  isSponsored?: boolean;
}

export function getTailoredTravelDeals(
  itinerary: Itinerary,
  currency: SupportedCurrency,
  language: SupportedLanguage
): TravelDeal[] {
  const waypoints = itinerary.waypoints || [];
  const startWp = waypoints[0];
  const endWp = waypoints[waypoints.length - 1] || startWp;

  const { regionCode } = detectRegion(startWp, endWp);

  const deals: TravelDeal[] = [];

  // Regional tailored deals
  switch (regionCode) {
    case 'osaka': {
      deals.push(
        {
          id: 'deal_osaka_castle_ticket',
          category: 'ticket',
          title: '大阪城天守閣 日時指定WEB優先入場チケット',
          description: '現地窓口の長い待機列をスキップ！スマホのQRコードをかざすだけで直接天守閣に入場できます。',
          provider: '公式パートナー (Klook / Webket)',
          priceJPY: 600,
          tag: '待機列スキップ',
          badgeColor: 'bg-emerald-500',
          rating: 4.8,
          reviewCount: 3820,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('大阪城天守閣 WEBチケット予約'),
          targetWaypointName: '大阪城天守閣',
        },
        {
          id: 'deal_tsutenkaku_slider',
          category: 'ticket',
          title: '通天閣 タワースライダー＆特別展望台 優先セット券',
          description: '地上22mからスパイラル状に滑り降りる体験型アトラクション！事前予約で混雑時もスムーズ案内。',
          provider: 'アソビュー！/ 通天閣公式',
          priceJPY: 1900,
          originalPriceJPY: 2100,
          tag: '人気体験・割引',
          badgeColor: 'bg-amber-500',
          rating: 4.7,
          reviewCount: 1420,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('通天閣 タワースライダー 予約'),
          targetWaypointName: '通天閣・新世界',
        },
        {
          id: 'deal_osaka_hotel',
          category: 'hotel',
          title: `新大阪・梅田周辺の人気ホテル比較（駅徒歩5分圏内）`,
          description: '翌日の新幹線移動や神戸・京都方面へのアクセスに抜群！早期割＆朝食バイキング付きプラン多数。',
          provider: '楽天トラベル / Booking.com',
          priceJPY: 8500,
          tag: '直前割あり',
          badgeColor: 'bg-blue-600',
          rating: 4.6,
          reviewCount: 5210,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('新大阪駅 梅田 ホテル 予約 楽天トラベル'),
          targetWaypointName: '新大阪駅',
        },
        {
          id: 'deal_dotonbori_cruise',
          category: 'ticket',
          title: 'とんぼりリバークルーズ＆道頓堀グルメクーポン',
          description: '戎橋グリコサイン前を船上から見上げる人気ミニクルーズ！たこ焼き名店の食べ比べ特典付き。',
          provider: '一本松海運 / 大阪周遊',
          priceJPY: 1500,
          tag: 'フォトスポット',
          badgeColor: 'bg-pink-600',
          rating: 4.7,
          reviewCount: 980,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('とんぼりリバークルーズ 予約'),
          targetWaypointName: '道頓堀・心斎橋',
        },
        {
          id: 'deal_kobe_harbor_dinner',
          category: 'dining',
          title: '神戸ハーバーランド モザイク夜景レストラン予約',
          description: '神戸港のライトアップと観覧車を望む特等席。神戸牛ステーキコースや記念日ディナーに最適。',
          provider: '一休.comレストラン / 食べログ',
          priceJPY: 5500,
          tag: '夜景確約席',
          badgeColor: 'bg-indigo-600',
          rating: 4.9,
          reviewCount: 640,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('神戸ハーバーランド モザイク レストラン 予約 一休'),
          targetWaypointName: '神戸ハーバーランド',
        }
      );
      break;
    }

    case 'kyoto': {
      deals.push(
        {
          id: 'deal_kyoto_kimono',
          category: 'ticket',
          title: '京都・清水寺＆祇園 着物・浴衣レンタル（ヘアセット込）',
          description: '手ぶらで来店OK！プロの着付けとヘアセットで風情ある石畳の二年坂・産寧坂を着物で散策。',
          provider: 'じゃらん / Klook',
          priceJPY: 3500,
          originalPriceJPY: 4500,
          tag: '女性・カップル人気',
          badgeColor: 'bg-rose-500',
          rating: 4.9,
          reviewCount: 2890,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('京都 清水寺 着物レンタル 予約'),
          targetWaypointName: '清水寺・音羽の滝',
        },
        {
          id: 'deal_sagano_railway',
          category: 'transit',
          title: '嵯峨野トロッコ列車 指定席チケット事前予約',
          description: '保津川渓谷の四季折々の自然を間近に感じる観光列車。紅葉・新緑時期の満席対策に事前確保必須！',
          provider: 'JR西日本 / 嵯峨野観光鉄道',
          priceJPY: 880,
          tag: '人気観光列車',
          badgeColor: 'bg-emerald-600',
          rating: 4.8,
          reviewCount: 1750,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('嵯峨野トロッコ列車 チケット予約 e5489'),
          targetWaypointName: '嵐山・竹林の小径',
        },
        {
          id: 'deal_kyoto_hotel',
          category: 'hotel',
          title: '京都駅周辺・四条烏丸の町家ホテル＆旅館',
          description: '観光拠点に最適。大浴場完備ホテルや風情ある町家ステイをお得なタイムセール価格で比較。',
          provider: '一休.com / 楽天トラベル',
          priceJPY: 9800,
          tag: '露天風呂・朝食付',
          badgeColor: 'bg-blue-600',
          rating: 4.7,
          reviewCount: 4120,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('京都駅 ホテル 旅館 予約 一休'),
          targetWaypointName: '京都駅',
        },
        {
          id: 'deal_kyoto_gourmet',
          category: 'dining',
          title: '祇園・先斗町の老舗湯豆腐＆京料理 懐石予約',
          description: '鴨川のせせらぎを聞きながら旬の京野菜と自家製豆腐を味わう至福のひととき。個室確約プランあり。',
          provider: '一休.com / 食べログ',
          priceJPY: 4200,
          tag: '伝統の味・個室あり',
          badgeColor: 'bg-amber-600',
          rating: 4.8,
          reviewCount: 890,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('京都 祇園 湯豆腐 京料理 予約'),
        }
      );
      break;
    }

    case 'hokkaido': {
      deals.push(
        {
          id: 'deal_otaru_cruise',
          category: 'ticket',
          title: '小樽運河 デイクルーズ＆ナイトクルーズ乗船WEB予約',
          description: 'ガス灯と石造倉庫群が幻想的に輝く小樽運河を船上からめぐる大人気ツアー。事前予約で優先乗船！',
          provider: '小樽運河クルーズ公式 / じゃらん',
          priceJPY: 1800,
          tag: '小樽必見ツアー',
          badgeColor: 'bg-cyan-600',
          rating: 4.9,
          reviewCount: 2150,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('小樽運河クルーズ 予約'),
          targetWaypointName: '小樽運河・堺町通り',
        },
        {
          id: 'deal_sapporo_hotel',
          category: 'hotel',
          title: 'JR札幌駅直結＆大通公園周辺ホテル（天然温泉付き）',
          description: '北海道観光の拠点にぴったり。北海道産イクラかけ放題の豪華朝食バイキングプランが人気！',
          provider: 'じゃらん / Booking.com',
          priceJPY: 7800,
          tag: '天然温泉・いくら丼',
          badgeColor: 'bg-blue-600',
          rating: 4.8,
          reviewCount: 3640,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('札幌駅 ホテル 温泉 朝食いくら 予約'),
          targetWaypointName: 'JR札幌駅',
        },
        {
          id: 'deal_sapporo_crab_genghis',
          category: 'dining',
          title: 'すすきの ジンギスカン＆三大蟹食べ比べ 席予約',
          description: '生ラムジンギスカンやタラバ・ズワイ・毛蟹を堪能！行列必至の名店をスムーズにWEB予約。',
          provider: 'ホットペッパーグルメ / 食べログ',
          priceJPY: 4800,
          tag: '名店確約席',
          badgeColor: 'bg-rose-600',
          rating: 4.7,
          reviewCount: 1120,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('すすきの ジンギスカン カニ 予約'),
          targetWaypointName: 'すすきの・ラーメン横丁',
        }
      );
      break;
    }

    case 'fukuoka': {
      deals.push(
        {
          id: 'deal_dazaifu_gourmet_pass',
          category: 'transit',
          title: '西鉄「太宰府・柳川 観光きっぷ」WEBデジタル乗車券',
          description: '西鉄電車往復割引＋梅ヶ枝餅引換券やクーポンがスマホ1台で使えるお得なモバイルチケット。',
          provider: '西鉄電車公式 / my route',
          priceJPY: 1100,
          originalPriceJPY: 1300,
          tag: 'デジタル割引券',
          badgeColor: 'bg-emerald-600',
          rating: 4.8,
          reviewCount: 890,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('太宰府 柳川 観光きっぷ 西鉄'),
          targetWaypointName: '太宰府天満宮',
        },
        {
          id: 'deal_hakata_hotel',
          category: 'hotel',
          title: '博多駅直結＆中洲川端周辺の人気ビジネス・リゾートホテル',
          description: '福岡空港から地下鉄5分の好アクセス。屋上露天風呂や明太子朝食バイキング付きプラン多数。',
          provider: '楽天トラベル / じゃらん',
          priceJPY: 8200,
          tag: '駅直結・大浴場',
          badgeColor: 'bg-blue-600',
          rating: 4.7,
          reviewCount: 3100,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('博多駅 ホテル 予約 楽天トラベル'),
          targetWaypointName: 'JR博多駅',
        },
        {
          id: 'deal_hakata_mizutaki',
          category: 'dining',
          title: '中洲・博多名物 博多水炊き＆もつ鍋老舗 席予約',
          description: '濃厚な白濁鶏ガラスープの水炊きや極上国産牛もつ鍋。個室でゆったり楽しむ博多の夜。',
          provider: '食べログ / ぐるなび',
          priceJPY: 3800,
          tag: '博多名物',
          badgeColor: 'bg-amber-600',
          rating: 4.9,
          reviewCount: 1450,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('博多 水炊き もつ鍋 予約'),
          targetWaypointName: 'キャナルシティ博多・中洲',
        }
      );
      break;
    }

    case 'tokyo':
    default: {
      deals.push(
        {
          id: 'deal_shibuya_sky',
          category: 'ticket',
          title: 'SHIBUYA SKY (渋谷スカイ) 日時指定WEB入場チケット',
          description: '地上229mからの360度パノラマ絶景！当日券完売が多いため、事前の日時指定WEB予約が必須です。',
          provider: 'SHIBUYA SKY公式 / Webket',
          priceJPY: 2200,
          tag: '大人気・事前予約必須',
          badgeColor: 'bg-purple-600',
          rating: 4.9,
          reviewCount: 5410,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('SHIBUYA SKY チケット予約'),
          targetWaypointName: '渋谷スクランブル交差点',
        },
        {
          id: 'deal_skytree_ticket',
          category: 'ticket',
          title: '東京スカイツリー 展望デッキ＆天望回廊 前売り割引セット券',
          description: '現地購入より最大400円お得！混雑時も専用レーンでスムーズに入場できるモバイルバウチャー。',
          provider: '東京スカイツリー公式 / アソビュー',
          priceJPY: 2700,
          originalPriceJPY: 3100,
          tag: '前売り割引',
          badgeColor: 'bg-blue-600',
          rating: 4.8,
          reviewCount: 4200,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('東京スカイツリー 前売りチケット 予約'),
          targetWaypointName: '東京スカイツリー',
        },
        {
          id: 'deal_tokyo_hotel',
          category: 'hotel',
          title: '東京駅・銀座・日本橋周辺ホテル（東京観光のベスト拠点）',
          description: '新幹線やJR各線・地下鉄へのアクセス抜群。洗練された客室と快適な滞在をお得に予約。',
          provider: '一休.com / 楽天トラベル',
          priceJPY: 11000,
          tag: '駅近・ハイクラス',
          badgeColor: 'bg-blue-600',
          rating: 4.8,
          reviewCount: 6100,
          bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('東京駅周辺 ホテル 予約 一休'),
          targetWaypointName: '東京駅',
        }
      );
      break;
    }
  }

  // Universal traveler service deals (Luggage storage & Travel eSIM / Passes)
  deals.push(
    {
      id: 'deal_luggage_storage',
      category: 'service',
      title: '手荷物預かり事前予約「ecbo cloak」(駅のコインロッカー満杯対策)',
      description: 'スーツケースを駅ナカ・駅チカの提携カフェや店舗にスマホで確実に預け入れ。ロッカー空き探し不要！',
      provider: 'ecbo cloak (エクボクローク)',
      priceJPY: 800,
      tag: '手ぶら観光',
      badgeColor: 'bg-emerald-600',
      rating: 4.8,
      reviewCount: 2200,
      bookingUrl: 'https://cloak.ecbo.io/',
      isSponsored: true,
    },
    {
      id: 'deal_japan_esim',
      category: 'service',
      title: '日本全国対応 5G/4G 高速無制限 eSIM (QR即時アクティベーション)',
      description: 'SIM差し替え不要！docomo/SoftBank回線でどこでも超高速通信。地図やナビ、カメラARもサクサク動作。',
      provider: 'Japan Travel eSIM',
      priceJPY: 1200,
      originalPriceJPY: 1600,
      tag: '旅行者必須',
      badgeColor: 'bg-cyan-600',
      rating: 4.9,
      reviewCount: 3900,
      bookingUrl: 'https://www.google.com/search?q=' + encodeURIComponent('日本旅行 eSIM おすすめ 即時発行'),
      isSponsored: true,
    },
    {
      id: 'deal_shinkansen_ticket',
      category: 'transit',
      title: 'JR新幹線・特急チケット「スマートEX / えきねっと」ネット予約',
      description: 'みどりの窓口に並ばずスマホで座席指定＆予約！手持ちのSuica/ICOCAを紐づければタッチ乗車可能。',
      provider: 'JR各社 (スマートEX / えきねっと)',
      priceJPY: 3000,
      tag: 'チケットレス',
      badgeColor: 'bg-blue-600',
      rating: 4.9,
      reviewCount: 8900,
      bookingUrl: 'https://smart-ex.jp/',
    }
  );

  return deals;
}
