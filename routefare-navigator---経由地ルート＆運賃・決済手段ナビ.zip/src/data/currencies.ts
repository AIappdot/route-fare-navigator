import { SupportedCurrency } from '../types';

export interface CurrencyInfo {
  code: SupportedCurrency;
  symbol: string;
  nameJa: string;
  nameEn: string;
  rateFromJPY: number; // 1 JPY = X in this currency
  decimals: number;
}

// Default base exchange rates (1 JPY = ...)
export const CURRENCY_RATES: Record<SupportedCurrency, CurrencyInfo> = {
  JPY: { code: 'JPY', symbol: '¥', nameJa: '日本円 (JPY)', nameEn: 'Japanese Yen', rateFromJPY: 1, decimals: 0 },
  USD: { code: 'USD', symbol: '$', nameJa: '米ドル (USD)', nameEn: 'US Dollar', rateFromJPY: 0.0067, decimals: 2 },
  EUR: { code: 'EUR', symbol: '€', nameJa: 'ユーロ (EUR)', nameEn: 'Euro', rateFromJPY: 0.0062, decimals: 2 },
  GBP: { code: 'GBP', symbol: '£', nameJa: '英ポンド (GBP)', nameEn: 'British Pound', rateFromJPY: 0.0053, decimals: 2 },
  TWD: { code: 'TWD', symbol: 'NT$', nameJa: '台湾ドル (TWD)', nameEn: 'New Taiwan Dollar', rateFromJPY: 0.215, decimals: 0 },
  KRW: { code: 'KRW', symbol: '₩', nameJa: '韓国ウォン (KRW)', nameEn: 'South Korean Won', rateFromJPY: 9.15, decimals: 0 },
  CNY: { code: 'CNY', symbol: '¥', nameJa: '人民元 (CNY)', nameEn: 'Chinese Yuan', rateFromJPY: 0.485, decimals: 1 },
  AUD: { code: 'AUD', symbol: 'A$', nameJa: '豪ドル (AUD)', nameEn: 'Australian Dollar', rateFromJPY: 0.0102, decimals: 2 },
  CAD: { code: 'CAD', symbol: 'C$', nameJa: 'カナダドル (CAD)', nameEn: 'Canadian Dollar', rateFromJPY: 0.0093, decimals: 2 },
  SGD: { code: 'SGD', symbol: 'S$', nameJa: 'シンガポールドル (SGD)', nameEn: 'Singapore Dollar', rateFromJPY: 0.0089, decimals: 2 },
};

/**
 * Convert JPY amount to target currency
 */
export function convertJPY(amountInJPY: number, targetCurrency: SupportedCurrency): number {
  const currency = CURRENCY_RATES[targetCurrency] || CURRENCY_RATES.JPY;
  return amountInJPY * currency.rateFromJPY;
}

/**
 * Format currency amount with symbol and appropriate decimals
 */
export function formatCurrency(amountInJPY: number, targetCurrency: SupportedCurrency): string {
  const currency = CURRENCY_RATES[targetCurrency] || CURRENCY_RATES.JPY;
  const converted = convertJPY(amountInJPY, targetCurrency);
  
  if (targetCurrency === 'JPY' || targetCurrency === 'KRW' || targetCurrency === 'TWD') {
    return `${currency.symbol}${Math.round(converted).toLocaleString()}`;
  }
  
  return `${currency.symbol}${converted.toFixed(currency.decimals)}`;
}

/**
 * Format dual currency: e.g. "¥210 ($1.41)"
 */
export function formatDualCurrency(amountInJPY: number, targetCurrency: SupportedCurrency): string {
  const primary = formatCurrency(amountInJPY, targetCurrency);
  if (targetCurrency === 'JPY') {
    return primary;
  }
  return `${primary} (約 ¥${Math.round(amountInJPY).toLocaleString()})`;
}
