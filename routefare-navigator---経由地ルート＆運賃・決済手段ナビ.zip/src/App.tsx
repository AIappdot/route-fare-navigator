/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SupportedLanguage, SupportedCurrency, Waypoint, RouteLeg } from './types';
import { PRESET_ITINERARIES } from './data/presetItineraries';
import { TRANSLATIONS } from './i18n/translations';
import { formatCurrency, formatDualCurrency } from './data/currencies';
import {
  recalculateItinerarySchedule,
  calculatePassengerFare,
  generateGoogleMapsUrl
} from './services/routeCalculator';
import { Header } from './components/Header';
import { CostSummaryCard } from './components/CostSummaryCard';
import { WaypointEditor } from './components/WaypointEditor';
import { TimelineView } from './components/TimelineView';
import { MapViewer } from './components/MapViewer';
import { PaymentGuideModal } from './components/PaymentGuideModal';
import { CameraARView } from './components/CameraARView';
import { VoiceAssistant } from './components/VoiceAssistant';
import { TravelDealsPanel } from './components/TravelDealsPanel';
import {
  MapPin,
  Clock,
  Wallet,
  ArrowRight,
  Sparkles,
  Printer,
  Copy,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  Share2,
  Camera,
  Volume2,
  Mic,
  Navigation
} from 'lucide-react';

export default function App() {
  // Google Maps API Key: from env or provided fallback
  const apiKey =
    import.meta.env.VITE_GOOGLE_MAPS_API_KEY ||
    'AIzaSyCwYo_mC4jdA5UBoCwUO-t2PJp24JM7VfA';

  // Localization and Currency
  const [language, setLanguage] = useState<SupportedLanguage>('ja');
  const [currency, setCurrency] = useState<SupportedCurrency>('JPY');

  // Presets and Itinerary State: default to Osaka & Kobe
  const [selectedPresetKey, setSelectedPresetKey] = useState<string>('osaka_kobe');
  const initialPreset = PRESET_ITINERARIES.osaka_kobe;

  const [itinerary, setItinerary] = useState(initialPreset.itinerary);
  const [legs, setLegs] = useState<RouteLeg[]>(initialPreset.legs);
  const [dayPassRecommendation, setDayPassRecommendation] = useState(
    initialPreset.dayPassRecommendation
  );

  // Map focus interaction
  const [focusedWaypointIndex, setFocusedWaypointIndex] = useState<number | null>(null);
  const [focusedLegIndex, setFocusedLegIndex] = useState<number | null>(null);

  // Modal and Assistant States
  const [isPaymentGuideOpen, setIsPaymentGuideOpen] = useState(false);
  const [isAROpen, setIsAROpen] = useState(false);
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [activeVoiceLegIndex, setActiveVoiceLegIndex] = useState<number | null>(0);
  const [copied, setCopied] = useState(false);

  const t = TRANSLATIONS[language];

  // Load preset itinerary
  const handleSelectPreset = (key: string) => {
    const preset = PRESET_ITINERARIES[key];
    if (!preset) return;
    setSelectedPresetKey(key);
    setItinerary(preset.itinerary);
    setLegs(preset.legs);
    setDayPassRecommendation(preset.dayPassRecommendation);
    setFocusedWaypointIndex(null);
    setFocusedLegIndex(null);
  };

  // Recalculate itinerary legs and schedule whenever waypoints, start time, or stay times change
  const handleUpdateWaypoints = (updatedWaypoints: Waypoint[]) => {
    const updatedItinerary = { ...itinerary, waypoints: updatedWaypoints };
    setItinerary(updatedItinerary);

    const recalculated = recalculateItinerarySchedule(updatedItinerary, legs);
    setLegs(recalculated);
  };

  const handleUpdateStartDateTime = (startDateTime: string) => {
    const updatedItinerary = { ...itinerary, startDateTime };
    setItinerary(updatedItinerary);

    const recalculated = recalculateItinerarySchedule(updatedItinerary, legs);
    setLegs(recalculated);
  };

  const handleUpdatePassengers = (passengers: {
    adults: number;
    children: number;
    seniors: number;
  }) => {
    setItinerary({ ...itinerary, passengers });
  };

  // Focus actions
  const handleFocusWaypoint = (idx: number) => {
    setFocusedWaypointIndex(idx);
    setFocusedLegIndex(null);
  };

  const handleFocusLeg = (idx: number) => {
    setFocusedLegIndex(idx);
    setFocusedWaypointIndex(null);
  };

  // AR & Voice triggers
  const handleOpenAR = (waypointIndex?: number) => {
    if (typeof waypointIndex === 'number') {
      setFocusedWaypointIndex(waypointIndex);
    }
    setIsAROpen(true);
  };

  const handleOpenVoice = (legIndex?: number) => {
    if (typeof legIndex === 'number') {
      setActiveVoiceLegIndex(legIndex);
    }
    setIsVoiceOpen(true);
  };

  // Open Google Maps multi-stop URL
  const handleOpenGoogleMaps = () => {
    const url = generateGoogleMapsUrl(itinerary.waypoints);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Copy structured itinerary to clipboard
  const handleCopyItinerary = () => {
    const totalTransitJPY = legs.reduce((acc, l) => acc + (l.totalFare || 0), 0);
    const passengerTotalJPY = calculatePassengerFare(totalTransitJPY, itinerary.passengers);

    let summaryText = `【${t.appName} - ${itinerary.title}】\n`;
    summaryText += `■ 地域: ${itinerary.region} / ${itinerary.city}\n`;
    summaryText += `■ 旅行開始: ${itinerary.startDateTime.replace('T', ' ')}\n`;
    summaryText += `■ 人数: 大人${itinerary.passengers.adults}名${
      itinerary.passengers.children ? `、子ども${itinerary.passengers.children}名` : ''
    }\n`;
    summaryText += `■ 最終移動費 合計: ${formatDualCurrency(passengerTotalJPY, currency)}\n\n`;

    summaryText += `▼ 区間ごとの詳細ルート・運賃・決済手段:\n`;
    legs.forEach((leg, i) => {
      summaryText += `------------------------------------\n`;
      summaryText += `[区間 ${i + 1}] ${leg.fromName} → ${leg.toName} (${leg.regionName})\n`;
      summaryText += `・利用路線/バス: ${leg.summaryLine}\n`;
      summaryText += `・時刻: ${leg.departureTime} 発 → ${leg.arrivalTime} 着 (${leg.transitDurationMinutes}分 / ${leg.totalDistanceKm}km)\n`;
      summaryText += `・運賃: ${formatCurrency(leg.totalFare, currency)} (1名あたり)\n`;
      summaryText += `・推奨決済: ${leg.paymentDossier?.bestRecommendation || '交通系ICカード / クレカタッチ'}\n`;
      if (leg.paymentDossier?.cashRequirement && leg.paymentDossier.cashRequirement !== '不要。') {
        summaryText += `・現金注意: ${leg.paymentDossier.cashRequirement}\n`;
      }
      const toWp = itinerary.waypoints.find((w) => w.id === leg.toWaypointId);
      if (toWp && toWp.stayMinutes > 0) {
        summaryText += `・到着後滞在: ${toWp.name}にて ${toWp.stayMinutes}分滞在\n`;
      }
    });

    summaryText += `------------------------------------\n`;
    summaryText += `Googleマップで全経路を確認: ${generateGoogleMapsUrl(itinerary.waypoints)}\n`;

    navigator.clipboard.writeText(summaryText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrintItinerary = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-800 font-sans flex flex-col antialiased selection:bg-blue-600 selection:text-white">
      
      {/* App Header */}
      <Header
        language={language}
        setLanguage={setLanguage}
        currency={currency}
        setCurrency={setCurrency}
        selectedPresetKey={selectedPresetKey}
        onSelectPreset={handleSelectPreset}
        onOpenPaymentGuide={() => setIsPaymentGuideOpen(true)}
        onOpenAR={() => handleOpenAR()}
        onOpenVoice={() => handleOpenVoice()}
        onCopyItinerary={handleCopyItinerary}
        onPrintItinerary={handlePrintItinerary}
        onOpenGoogleMaps={handleOpenGoogleMaps}
        copied={copied}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Top Summary Banner: Final Cost, Time & Passenger Options */}
        <CostSummaryCard
          legs={legs}
          waypoints={itinerary.waypoints}
          currency={currency}
          language={language}
          passengers={itinerary.passengers}
          onUpdatePassengers={handleUpdatePassengers}
          dayPassRecommendation={dayPassRecommendation}
        />

        {/* 2-Column Responsive Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column (7 cols): Route Configuration & Segment Breakdown Timeline */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Waypoint Editor (Stops, Stay Times, Departure Time) */}
            <WaypointEditor
              waypoints={itinerary.waypoints}
              startDateTime={itinerary.startDateTime}
              onUpdateStartDateTime={handleUpdateStartDateTime}
              onUpdateWaypoints={handleUpdateWaypoints}
              language={language}
              onFocusWaypoint={handleFocusWaypoint}
            />

            {/* Segment Breakdown Timeline (Lines, Bus directions, Fares, Payment methods) */}
            <TimelineView
              legs={legs}
              waypoints={itinerary.waypoints}
              currency={currency}
              language={language}
              passengers={itinerary.passengers}
              onFocusLeg={handleFocusLeg}
              onOpenAR={(wpIdx) => handleOpenAR(wpIdx)}
              onOpenVoice={(legIdx) => handleOpenVoice(legIdx)}
            />

          </div>

          {/* Right Column (5 cols): Interactive Google Maps View & Quick Cards */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-20">
            
            {/* Interactive Map View */}
            <MapViewer
              waypoints={itinerary.waypoints}
              legs={legs}
              language={language}
              focusedWaypointIndex={focusedWaypointIndex}
              focusedLegIndex={focusedLegIndex}
              apiKey={apiKey}
            />

            {/* Floating Action Quick Triggers for Camera AR & Voice */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => handleOpenAR()}
                className="p-3.5 bg-gradient-to-tr from-purple-600 via-indigo-600 to-purple-700 hover:from-purple-700 hover:to-indigo-700 text-white rounded-2xl shadow-md transition active:scale-95 flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center"
              >
                <Camera className="w-5 h-5 text-cyan-300" />
                <span className="font-bold text-xs">カメラAR矢印</span>
                <span className="text-[10px] text-purple-200">目的地をカメラ空間で誘導</span>
              </button>

              <button
                type="button"
                onClick={() => handleOpenVoice()}
                className="p-3.5 bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-700 hover:from-cyan-700 hover:to-blue-700 text-white rounded-2xl shadow-md transition active:scale-95 flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center"
              >
                <Volume2 className="w-5 h-5 text-amber-300" />
                <span className="font-bold text-xs">音声案内＆AI対話</span>
                <span className="text-[10px] text-blue-200">読み上げ・音声で質問</span>
              </button>
            </div>

            {/* Quick Trip Route Overview Card */}
            <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center justify-between">
                <span>行程クイックフロー</span>
                <span className="text-[11px] text-emerald-600 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full">
                  地域交通連動
                </span>
              </h3>

              <div className="relative pl-6 space-y-3 text-xs before:content-[''] before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                {itinerary.waypoints.map((wp, i) => {
                  const isStart = i === 0;
                  const isEnd = i === itinerary.waypoints.length - 1;
                  return (
                    <div key={wp.id} className="relative flex items-baseline justify-between gap-2">
                      <div
                        className={`absolute -left-6 top-1 w-2.5 h-2.5 rounded-full ring-2 ring-white ${
                          isStart ? 'bg-emerald-500' : isEnd ? 'bg-rose-500' : 'bg-blue-500'
                        }`}
                      />
                      <span className="font-semibold text-slate-800 line-clamp-1">
                        {wp.name}
                      </span>
                      <span className="text-slate-400 font-medium shrink-0">
                        {wp.stayMinutes > 0 ? `${wp.stayMinutes}分滞在` : isEnd ? '到着' : '出発'}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Share & Open Google Maps Buttons */}
              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <button
                  type="button"
                  onClick={handleCopyItinerary}
                  className="flex-1 py-2 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>{copied ? t.copied : '旅程を共有'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleOpenGoogleMaps}
                  className="flex-1 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-blue-200" />
                  <span>Google マップ</span>
                </button>
              </div>

            </div>

            {/* Nationwide Transit & Payment Dossier Notice */}
            <div className="p-3.5 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl flex items-start gap-2.5 text-xs">
              <ShieldCheck className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
              <div>
                <span className="font-bold text-blue-950 block">
                  日本全国の地域交通・決済ルールに完全対応
                </span>
                <span className="text-blue-800 mt-0.5 block leading-relaxed">
                  大阪ではOsaka MetroやJR西日本、京都では市バス・京阪・嵐電、福岡では全駅タッチ決済対応の地下鉄・西鉄など、各地域で実在する路線と決済手段を厳密に案内します。
                </span>
              </div>
            </div>

          </div>

        </div>

        {/* Tailored Booking, Tickets & Travel Deals Space (入力内容に応じたおすすめ予約・お得情報スペース) */}
        <TravelDealsPanel
          itinerary={itinerary}
          currency={currency}
          language={language}
        />

      </main>

      {/* Payment Guide Modal */}
      <PaymentGuideModal
        isOpen={isPaymentGuideOpen}
        onClose={() => setIsPaymentGuideOpen(false)}
        language={language}
      />

      {/* Camera Live AR Wayfinding Arrow Modal */}
      <CameraARView
        isOpen={isAROpen}
        onClose={() => setIsAROpen(false)}
        waypoints={itinerary.waypoints}
        language={language}
      />

      {/* Multilingual Voice Assistant Modal */}
      <VoiceAssistant
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        legs={legs}
        waypoints={itinerary.waypoints}
        language={language}
        currency={currency}
        activeLegIndex={activeVoiceLegIndex}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 RouteFare Navigator - 日本全国 経由地ルート＆運賃・決済・AR・音声ナビゲーション</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Powered by Google Maps Platform & Gemini 3.8 Flash</span>
            <span>•</span>
            <button
              onClick={() => setIsPaymentGuideOpen(true)}
              className="hover:text-blue-600 transition underline cursor-pointer"
            >
              決済・乗り方ガイド
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
}
