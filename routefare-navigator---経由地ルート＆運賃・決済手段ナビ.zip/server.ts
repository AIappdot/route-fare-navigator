import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json());

// Initialize Gemini SDK with User-Agent header as required
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Google Maps API Key provided
const GOOGLE_MAPS_API_KEY =
  process.env.VITE_GOOGLE_MAPS_API_KEY ||
  'AIzaSyCwYo_mC4jdA5UBoCwUO-t2PJp24JM7VfA';

/**
 * Endpoint: Google Routes API (Modern Transit API) between two points
 */
app.post('/api/directions-transit', async (req, res) => {
  try {
    const { origin, destination, language = 'ja' } = req.body;

    if (!origin || !destination) {
      return res.status(400).json({ error: 'Origin and destination are required' });
    }

    const routesUrl = 'https://routes.googleapis.com/directions/v2:computeRoutes';
    const body = {
      origin: {
        location: {
          latLng: { latitude: parseFloat(origin.lat), longitude: parseFloat(origin.lng) },
        },
      },
      destination: {
        location: {
          latLng: { latitude: parseFloat(destination.lat), longitude: parseFloat(destination.lng) },
        },
      },
      travelMode: 'TRANSIT',
      computeAlternativeRoutes: false,
      languageCode: language || 'ja',
    };

    const response = await fetch(routesUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': GOOGLE_MAPS_API_KEY,
        'X-Goog-FieldMask': 'routes.duration,routes.distanceMeters,routes.legs,routes.travelAdvisory',
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (data.routes?.[0]?.legs?.[0]) {
      const leg = data.routes[0].legs[0];
      return res.json({
        success: true,
        distanceMeters: leg.distanceMeters || data.routes[0].distanceMeters,
        duration: leg.duration || data.routes[0].duration,
        steps: leg.steps || [],
        travelAdvisory: data.routes[0].travelAdvisory || null,
      });
    }

    return res.json({
      success: false,
      errorMessage: data.error?.message || 'Routes API fallback to regional engine',
    });
  } catch (error) {
    console.error('Error fetching Routes API:', error);
    return res.json({ success: false, error: 'Routes API unavailable' });
  }
});

/**
 * Endpoint: Multilingual Voice Q&A Assistant using Gemini 3.8 Flash
 */
app.post('/api/voice-qa', async (req, res) => {
  try {
    const { question, context, language = 'ja' } = req.body;

    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }

    const systemPrompt = `You are an expert travel, transit, and payments concierge for travelers in Japan and worldwide.
Your goal is to answer the user's specific travel question accurately and concisely.

CRITICAL INSTRUCTIONS:
1. GEOGRAPHIC ACCURACY:
   - If the user is in Osaka, refer ONLY to Osaka transit (Osaka Metro Midosuji/Sakaisuji/Nagahori lines, JR West Osaka Loop Line, Hankyu, Hanshin, Keihan, Nankai, Osaka City Bus). NEVER mention Tokyo Metro or JR East in Osaka!
   - If in Kyoto: Kyoto City Subway (Karasuma, Tozai), Kyoto City Bus (206, 205, etc.), Keihan Railway, Hankyu, Randen, JR Nara/Sagano Line. NEVER mention Tokyo Metro!
   - If in Hokkaido: Sapporo Municipal Subway, JR Hokkaido, Chuo Bus.
   - If in Fukuoka: Fukuoka City Subway (Kuko, Nanakuma, Hakozaki lines), Nishitetsu Bus & Railway, JR Kyushu.
   - If in Nagoya: Nagoya Municipal Subway (Higashiyama, Meijo), Meitetsu, JR Central.
   - If in Hiroshima: Hiroshima Electric Railway (Hiroden tram), JR Sanyo Line, Miyajima Ferry.
   - If in Okinawa: Okinawa Urban Monorail (Yui Rail), local buses.
2. PAYMENT PRECISION:
   - Explicitly detail payment options for the specific station, bus, or sightseeing spot.
   - Explain IC card rules (Suica, ICOCA, PASMO, PiTaPa, SUGOCA, etc.).
   - Explain Credit Card Contactless EMV tap adoption status for the specific line.
   - Explain spot admission/temple fee policies (e.g. many temples/shrines require CASH only for entrance, goshuin, and amulets).
3. MULTILINGUAL & VOICE-FRIENDLY:
   - Respond in the language code requested (${language}).
   - Keep the answer concise (2-4 clear sentences) so it can be spoken aloud naturally via Text-to-Speech.
   - Highlight practical tips like platform numbers, exact change requirements, and card tap locations.`;

    const prompt = `Context of current trip:
${JSON.stringify(context || {}, null, 2)}

User Question: ${question}

Provide a direct, helpful, and natural answer in language '${language}' for voice speech readout:`;

    const aiResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    const reply = aiResponse.text?.trim() || '案内を取得できませんでした。';

    return res.json({
      answer: reply,
      language: language,
    });
  } catch (error) {
    console.error('Error in /api/voice-qa:', error);
    // Graceful fallback response if API key is not present or rate limited
    return res.json({
      answer: 'この区間では交通系ICカード（SuicaやICOCA等）および主要改札でのタッチ決済がスムーズです。バスをご利用の際は運賃の支払い方式（前乗り前払いまたは後乗り後払い）にご注意ください。',
      language: req.body.language || 'ja',
    });
  }
});

// In dev, use Vite's connect instance as middleware; in prod, serve static dist
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`RouteFare Navigator server running on http://0.0.0.0:${port}`);
  });
}

startServer();
